// Headless UI smoke test (jsdom). Server must be running: PORT=3055 node tests/ui-smoke.js
const { JSDOM } = require('jsdom');
const fs = require('fs');
const BASE = `http://localhost:${process.env.PORT || 3000}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let bad = 0; const ok = (c, n) => { if (!c) bad++; console.log(`${c ? '  ✓' : '  ✗ FAIL'} ${n}`); };

(async () => {
  const html = fs.readFileSync(__dirname + '/../public/index.html', 'utf8').replace(/<script src="\/js\/app.js"><\/script>/, '');
  const dom = new JSDOM(html, { url: BASE + '/', runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  const errors = [];
  w.fetch = (u, o) => fetch(new URL(u, BASE), o);
  w.confirm = () => true;
  w.scrollTo = () => {}; w.Element.prototype.scrollIntoView = () => {};
  Object.defineProperty(w.HTMLElement.prototype, 'innerText', { get() { return this.textContent; }, set(v) { this.textContent = v; } });
  w.document.execCommand = () => false;
  w.addEventListener('error', (e) => errors.push(e.message));
  new (require('vm').Script)(fs.readFileSync(__dirname + '/../public/js/app.js', 'utf8')).runInContext(dom.getInternalVMContext());
  const $ = (id) => w.document.getElementById(id);
  await sleep(300);
  ok($('auth-page').style.display === 'block', 'unauthenticated → auth screen');

  $('login-email').value = 'admin@prepgrid.local'; $('login-pass').value = 'wrong';
  await w.doLogin(); await sleep(300);
  ok($('err-login').classList.contains('show'), 'bad login shows error');
  $('login-pass').value = process.env.ADMIN_PASSWORD || 'Admin@12345';
  await w.doLogin(); await sleep(600);
  ok($('main-app').style.display === 'block' && $('u-name').textContent === 'Admin', 'login → app shell');
  ok($('nav-admin').style.display === 'flex', 'admin nav visible');
  ok(/Good (morning|afternoon|evening), Admin/.test($('greeting').textContent), 'dashboard greeting');

  w.navigate('practice'); await sleep(700);
  ok($('q-list').children.length === 15, 'practice lists 15 questions');
  ok($('q-panel-title').textContent === 'Two Sum' && $('code-editor').textContent.includes('function twoSum'), 'first question + starter code loaded');
  $('code-editor').textContent = 'function twoSum(nums,target){const m=new Map();for(let i=0;i<nums.length;i++){const c=target-nums[i];if(m.has(c))return [m.get(c),i];m.set(nums[i],i);}return [];}';
  await w.runCode(false); await sleep(1200);
  ok(/All 3 test cases passed/.test($('run-output').textContent), 'Run → 3/3 passed');
  await w.submitCode(); await sleep(1500);
  ok(/Accepted/.test($('run-output').textContent) && $('q-list').querySelector('.q-check.solved'), 'Submit → accepted, row marked solved');
  w.toggleChip(w.document.querySelector('#difficulty-chips [data-val="Hard"]'), 'diff'); await sleep(500);
  ok($('q-list').children.length === 3, 'Hard filter → 3 questions');
  await w.loadQuestion(4); ok($('q-panel-diff').textContent === 'Medium', 'switch question');

  w.navigate('interview'); await sleep(500);
  ok(/unlimited/.test($('interview-usage').textContent), 'interview usage banner');
  await w.startInterview(); await sleep(600);
  ok($('interview-session').style.display === 'block' && $('chat-container').textContent.includes('Question 1'), 'interview started');
  $('user-answer').value = 'Closures capture variables because functions keep a reference to their lexical scope, for example counters. Trade-off: memory retention.';
  await w.submitAnswer(); await sleep(600);
  ok(/Score: \d+\/100/.test($('chat-container').textContent) && $('q-counter').textContent === '2', 'answer scored, next question shown');
  await w.endInterview(); await sleep(500);
  ok($('interview-setup').style.display === 'block', 'end session → setup');
  await w.showHistory(); await sleep(500);
  ok($('interview-history').style.display === 'block' && $('history-list').textContent.includes('Frontend Engineer'), 'history lists session');

  w.navigate('quiz'); await sleep(600);
  await w.startQuiz(); await sleep(600);
  ok($('quiz-active').style.display === 'block' && $('quiz-options').children.length === 4, 'quiz started with 4 options');
  for (let i = 0; i < 5; i++) { await w.selectOption(0); await sleep(250); w.nextQuestion(); await sleep(250); }
  await sleep(900);
  ok($('quiz-results').style.display === 'block' && /^\d\/5$/.test($('result-score').textContent), 'quiz results shown: ' + $('result-score').textContent);
  ok($('leaderboard-list').textContent.length > 0, 'leaderboard rendered');

  w.navigate('billing'); await sleep(500);
  ok($('billing-empty').style.display === 'block', 'billing page renders');
  w.navigate('admin'); await sleep(900);
  ok($('ad-questions').textContent === '15' && $('admin-q-table').children.length === 15, 'admin stats + questions table');
  w.adminTab('users'); await sleep(500); ok($('admin-u-table').children.length >= 1, 'admin users');
  w.adminTab('analytics'); await sleep(500); ok($('admin-chart-q').textContent.includes('Two Sum'), 'admin analytics from real data');
  w.showAddQuestion(); $('new-q-title').value = '<img src=x onerror=alert(1)>'; $('new-q-desc').value = 'xss test';
  await w.saveQuestion(); await sleep(600);
  ok(!$('admin-q-table').querySelector('img') && $('admin-q-table').textContent.includes('<img'), 'XSS: title rendered as text, not HTML');

  w.logout(); await sleep(100);
  ok($('auth-page').style.display === 'block', 'logout → auth screen');
  ok(errors.length === 0, 'no uncaught JS errors ' + errors.join('|'));
  console.log(bad ? `\n${bad} failed` : '\nUI smoke test passed'); process.exit(bad ? 1 : 0);
})();
