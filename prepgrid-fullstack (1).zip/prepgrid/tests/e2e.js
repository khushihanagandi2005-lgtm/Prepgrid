// End-to-end API test. Usage: PORT=3055 node tests/e2e.js   (server must be running, fresh DB, no ANTHROPIC key)
const BASE = `http://localhost:${process.env.PORT || 3000}/api`;
let pass = 0, fail = 0;
const ok = (c, name, extra = '') => { c ? pass++ : fail++; console.log(`${c ? '  ✓' : '  ✗ FAIL'} ${name}${c ? '' : ' ' + extra}`); };
async function api(method, path, body, token) {
  const r = await fetch(BASE + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
  let j = null; try { j = await r.json(); } catch {}
  return { status: r.status, ...j };
}

const SOL = {
  1: `function twoSum(nums,target){const m=new Map();for(let i=0;i<nums.length;i++){const c=target-nums[i];if(m.has(c))return [m.get(c),i];m.set(nums[i],i);}return [];}`,
  2: `function isValid(s){const st=[],p={')':'(',']':'[','}':'{'};for(const c of s){if('([{'.includes(c))st.push(c);else if(st.pop()!==p[c])return false;}return st.length===0;}`,
  3: `function mergeTwoLists(a,b){const d=new ListNode();let t=d;while(a&&b){if(a.val<=b.val){t.next=a;a=a.next;}else{t.next=b;b=b.next;}t=t.next;}t.next=a||b;return d.next;}`,
  4: `function levelOrder(root){if(!root)return [];const out=[];let q=[root];while(q.length){out.push(q.map(n=>n.val));q=q.flatMap(n=>[n.left,n.right]).filter(Boolean);}return out;}`,
  5: `function longestPalindrome(s){let b='';for(let c=0;c<s.length;c++)for(const [l0,r0] of [[c,c],[c,c+1]]){let l=l0,r=r0;while(l>=0&&r<s.length&&s[l]===s[r]){l--;r++;}if(r-l-1>b.length)b=s.slice(l+1,r);}return b;}`,
  6: `function numIslands(g){let n=0;const R=g.length,C=R?g[0].length:0;const dfs=(i,j)=>{if(i<0||j<0||i>=R||j>=C||g[i][j]!=='1')return;g[i][j]='0';dfs(i+1,j);dfs(i-1,j);dfs(i,j+1);dfs(i,j-1);};for(let i=0;i<R;i++)for(let j=0;j<C;j++)if(g[i][j]==='1'){n++;dfs(i,j);}return n;}`,
  7: `function coinChange(coins,amount){const dp=Array(amount+1).fill(Infinity);dp[0]=0;for(let a=1;a<=amount;a++)for(const c of coins)if(c<=a)dp[a]=Math.min(dp[a],dp[a-c]+1);return dp[amount]===Infinity?-1:dp[amount];}`,
  8: `function wordBreak(s,d){const set=new Set(d),dp=Array(s.length+1).fill(false);dp[0]=true;for(let i=1;i<=s.length;i++)for(let j=0;j<i;j++)if(dp[j]&&set.has(s.slice(j,i))){dp[i]=true;break;}return dp[s.length];}`,
  9: `function validTree(n,e){if(e.length!==n-1)return false;const p=[...Array(n).keys()];const f=x=>p[x]===x?x:(p[x]=f(p[x]));for(const [a,b] of e){const ra=f(a),rb=f(b);if(ra===rb)return false;p[ra]=rb;}return true;}`,
  10: `function trap(h){let l=0,r=h.length-1,lm=0,rm=0,w=0;while(l<r){if(h[l]<h[r]){lm=Math.max(lm,h[l]);w+=lm-h[l++];}else{rm=Math.max(rm,h[r]);w+=rm-h[r--];}}return w;}`,
  11: `function totalNQueens(n){let c=0;const cols=new Set(),d1=new Set(),d2=new Set();const go=r=>{if(r===n){c++;return;}for(let i=0;i<n;i++){if(cols.has(i)||d1.has(r-i)||d2.has(r+i))continue;cols.add(i);d1.add(r-i);d2.add(r+i);go(r+1);cols.delete(i);d1.delete(r-i);d2.delete(r+i);}};go(0);return c;}`,
  12: `function serialize(root){const o=[];const go=n=>{if(!n){o.push('#');return;}o.push(n.val);go(n.left);go(n.right);};go(root);return o.join(',');}
function deserialize(d){const a=d.split(',');let i=0;const go=()=>{const v=a[i++];if(v==='#')return null;const n=new TreeNode(Number(v));n.left=go();n.right=go();return n;};return go();}`,
  13: `SELECT name, salary, department FROM Employee e WHERE salary > (SELECT AVG(salary) FROM Employee WHERE department = e.department)`,
  14: `SELECT MAX(salary) AS SecondHighestSalary FROM Employee WHERE salary < (SELECT MAX(salary) FROM Employee)`,
  15: `function mergeSort(a){if(a.length<2)return a.slice();const m=a.length>>1,l=mergeSort(a.slice(0,m)),r=mergeSort(a.slice(m));const o=[];let i=0,j=0;while(i<l.length&&j<r.length)o.push(l[i]<=r[j]?l[i++]:r[j++]);return o.concat(l.slice(i),r.slice(j));}`,
};

(async () => {
  console.log('Auth');
  const email = `t${Date.now()}@example.com`;
  let r = await api('POST', '/auth/register', { firstName: 'Test', lastName: 'User', email, password: 'short' });
  ok(r.status === 400, 'rejects short password');
  r = await api('POST', '/auth/register', { firstName: 'Test', lastName: 'User', email, password: 'Password123' });
  ok(r.status === 201 && r.token, 'registers');
  const T = r.token;
  r = await api('POST', '/auth/register', { firstName: 'Test', email, password: 'Password123' });
  ok(r.status === 409, 'duplicate email rejected');
  r = await api('POST', '/auth/login', { email, password: 'wrong' });
  ok(r.status === 401, 'wrong password rejected');
  r = await api('POST', '/auth/login', { email, password: 'Password123' });
  ok(r.status === 200 && r.user.plan === 'Free', 'login ok, Free plan');
  r = await api('GET', '/me/dashboard');
  ok(r.status === 401, 'dashboard needs auth');
  r = await api('POST', '/auth/forgot', { email });
  const otp = r.devOtp; ok(/^\d{6}$/.test(otp || ''), 'OTP issued (dev)');
  r = await api('POST', '/auth/reset', { email, otp: '000000', newPassword: 'NewPassword1' });
  ok(r.status === 400, 'wrong OTP rejected');
  r = await api('POST', '/auth/reset', { email, otp, newPassword: 'NewPassword1' });
  ok(r.status === 200, 'password reset');
  r = await api('POST', '/auth/login', { email, password: 'NewPassword1' });
  ok(r.status === 200, 'login with new password');
  const U = r.token;

  console.log('Practice (admin = Pro, all 15 reference solutions)');
  const adm = await api('POST', '/auth/login', { email: 'admin@prepgrid.local', password: process.env.ADMIN_PASSWORD || 'Admin@12345' });
  const A = adm.token; ok(!!A, 'admin login');
  for (let id = 1; id <= 15; id++) {
    const lang = id === 13 || id === 14 ? 'SQL' : 'JavaScript';
    const run = await api('POST', `/questions/${id}/run`, { code: SOL[id], lang }, A);
    const sub = await api('POST', `/questions/${id}/submit`, { code: SOL[id], lang }, A);
    ok(run.ok && run.passed === run.total && sub.accepted, `Q${id} run ${run.passed}/${run.total}, submit ${sub.passed}/${sub.total}`, JSON.stringify(run.error || sub.results?.filter((x) => !x.passed)).slice(0, 300));
  }
  r = await api('POST', '/questions/1/submit', { code: 'function twoSum(){return [0,0]}', lang: 'JavaScript' }, A);
  ok(r.ok && !r.accepted, 'wrong answer is not accepted');
  ok(!JSON.stringify(r.results).includes('-8'), 'hidden test data is not leaked');
  const t0 = Date.now();
  r = await api('POST', '/questions/1/run', { code: 'function twoSum(){while(true){}}', lang: 'JavaScript' }, A);
  ok(r.ok && r.results.every((x) => /Time Limit/.test(x.error || '')) && Date.now() - t0 < 15000, 'infinite loop → TLE, server stays alive', JSON.stringify(r).slice(0, 200));
  r = await api('POST', '/questions/1/run', { code: `function twoSum(){ return String(typeof process) + typeof require; }`, lang: 'JavaScript' }, A);
  ok(r.ok && r.results[0].got === 'undefinedundefined', 'sandbox has no process/require', JSON.stringify(r).slice(0, 200));
  const escapes = [
    `this.constructor.constructor('return process')().pid`,
    `(()=>{}).constructor('return process')().pid`,
    `(function(){try{null.x}catch(e){return e.constructor.constructor('return process')().pid}})()`,
    `Object.getPrototypeOf(async function(){}).constructor('return process')().pid`,
    `[].constructor.constructor('return process')().pid`,
    `new Function('return process')().pid`,
    `eval('process.pid')`,
  ];
  for (const e of escapes) {
    r = await api('POST', '/questions/1/run', { code: `function twoSum(){ return ${e}; }`, lang: 'JavaScript' }, A);
    ok(r.ok && r.results.every((x) => !(typeof x.got === 'number' && x.got > 1)), `sandbox escape blocked: ${e.slice(0, 45)}`, JSON.stringify(r).slice(0, 250));
  }
  r = await api('POST', '/questions/1/run', { code: 'function twoSum( {', lang: 'JavaScript' }, A);
  ok(r.ok === false && /Unexpected|token|Syntax/i.test(r.error), 'syntax error reported');
  r = await api('POST', '/questions/1/run', { code: 'print(1)', lang: 'Python' }, A);
  ok(r.ok === false && /not enabled/.test(r.error), 'unsupported language reported clearly');
  r = await api('POST', '/questions/13/run', { code: 'DROP TABLE Employee', lang: 'SQL' }, A);
  ok(r.ok === false, 'non-SELECT SQL blocked');

  console.log('Free-tier gating');
  r = await api('GET', '/questions', null, U);
  ok(r.questions.filter((q) => q.locked).length === 5, '5 of 15 questions locked for Free');
  r = await api('POST', '/questions/12/run', { code: SOL[12], lang: 'JavaScript' }, U);
  ok(r.status === 402, 'locked question blocked server-side');
  r = await api('POST', '/questions/1/submit', { code: SOL[1], lang: 'JavaScript' }, U);
  ok(r.accepted && r.firstSolve, 'free user solves Q1');
  r = await api('POST', '/questions/1/bookmark', {}, U);
  ok(r.bookmarked === true, 'bookmark on');
  r = await api('GET', '/questions?topic=Arrays&sort=hard', null, U);
  ok(r.questions.length === 3 && r.questions[0].diff === 'Hard' && r.questions.find((q) => q.id === 1).solved, 'filter + sort + solved flag');
  r = await api('GET', '/quiz/leaderboard?topic=React%20Hooks', null, U);
  ok(r.status === 402, 'leaderboard is Pro-only');
  r = await api('GET', '/interview/history', null, U);
  ok(r.status === 402, 'history is Pro-only');

  console.log('Interview');
  r = await api('POST', '/interview/start', { role: 'Backend Engineer', difficulty: 'Medium (SDE-1)', duration: 30 }, U);
  ok(r.sessionId && r.question, 'start');
  const sid = r.sessionId;
  r = await api('POST', `/interview/${sid}/answer`, { answer: '' }, U);
  ok(r.status === 400, 'empty answer rejected');
  const long = 'Indexes speed up lookups because the database can use a B-tree instead of scanning every row. For example, an index on email makes login O(log n). The trade-off is slower writes and more storage, so index selectively.';
  r = await api('POST', `/interview/${sid}/answer`, { answer: long }, U);
  ok(r.score > 50 && r.next && r.next.index === 1, 'answer scored, next question served', JSON.stringify(r));
  r = await api('POST', `/interview/${sid}/skip`, {}, U);
  ok(r.skipped && r.next.index === 2, 'skip works');
  for (let i = 0; i < 5; i++) r = await api('POST', `/interview/${sid}/answer`, { answer: long }, U);
  r = await api('POST', `/interview/${sid}/answer`, { answer: long }, U);
  ok(r.done === true && r.summary.avgScore > 0, 'session completes after 8 questions', JSON.stringify(r));
  r = await api('POST', `/interview/${sid}/answer`, { answer: long }, U);
  ok(r.status === 409, 'cannot answer finished session');
  r = await api('GET', '/interview/usage', null, U);
  ok(r.used === 1 && r.limit === 5, 'usage counter');
  for (let i = 0; i < 4; i++) await api('POST', '/interview/start', { role: 'System Design', difficulty: 'Easy (Intern)', duration: 15 }, U);
  r = await api('POST', '/interview/start', { role: 'System Design', difficulty: 'Easy (Intern)', duration: 15 }, U);
  ok(r.status === 402 && r.upgrade, 'free interview limit (5/month) enforced');
  r = await api('POST', `/interview/${sid}/answer`, { answer: 'x' }, A);
  ok(r.status === 404, "cannot touch another user's session");

  console.log('Quiz');
  r = await api('POST', '/quiz/start', { topic: 'React Hooks', count: 5, timeMin: 10 }, U);
  ok(r.attemptId && r.questions.length === 5 && !('answer' in r.questions[0]), 'start; answers not sent to client');
  const qz = r.attemptId; const qs = r.questions;
  let correct = 0;
  for (let i = 0; i < qs.length; i++) {
    const a = await api('POST', `/quiz/${qz}/answer`, { qIndex: i, selected: 0 }, U);
    if (a.correct) correct++;
    if (i === 0) { const again = await api('POST', `/quiz/${qz}/answer`, { qIndex: 0, selected: a.correctIndex }, U); ok(again.selected === 0, 'first answer is final'); }
  }
  r = await api('POST', `/quiz/${qz}/finish`, {}, U);
  ok(r.correct === correct && r.total === 5 && typeof r.feedback === 'string', `finish → ${r.correct}/5 matches server-side grading`);
  r = await api('POST', '/quiz/start', { topic: 'Nope', count: 5, timeMin: 10 }, U);
  ok(r.status === 400, 'unknown topic rejected');
  await api('POST', '/quiz/start', { topic: 'SQL Queries', count: 5, timeMin: 5 }, U);
  await api('POST', '/quiz/start', { topic: 'SQL Queries', count: 5, timeMin: 5 }, U);
  r = await api('POST', '/quiz/start', { topic: 'SQL Queries', count: 5, timeMin: 5 }, U);
  ok(r.status === 402, 'free quiz limit (3/month) enforced');

  console.log('Dashboard');
  r = await api('GET', '/me/dashboard', null, U);
  ok(r.stats.solved === 1 && r.stats.interviews === 1 && r.stats.streak === 1 && r.grid.length === 28 && r.recent.length > 0, 'real stats, streak, grid, activity', JSON.stringify(r.stats));

  console.log('Billing');
  r = await api('POST', '/billing/verify', { orderId: 'sandbox_nope', paymentId: 'x' }, U);
  ok(r.status === 404, 'verify unknown order rejected');
  r = await api('POST', '/billing/order', {}, U);
  ok(r.mode === 'sandbox' && r.amount === 49900, 'order created (sandbox)');
  r = await api('POST', '/billing/verify', { orderId: r.orderId, paymentId: 'x' }, U);
  ok(r.user && r.user.plan === 'Pro', 'upgrade to Pro');
  r = await api('GET', '/billing', null, U);
  ok(r.history.length === 1 && r.history[0].status === 'paid', 'billing history');
  r = await api('GET', '/quiz/leaderboard?topic=React%20Hooks', null, U);
  ok(r.entries?.length === 1 && r.entries[0].me, 'Pro: leaderboard unlocked');
  r = await api('POST', '/questions/12/submit', { code: SOL[12], lang: 'JavaScript' }, U);
  ok(r.accepted, 'Pro: all questions unlocked');
  r = await api('GET', '/interview/history', null, U);
  ok(r.sessions?.length >= 1, 'Pro: history');

  console.log('Admin');
  r = await api('GET', '/admin/stats', null, U);
  ok(r.status === 403, 'non-admin blocked');
  r = await api('GET', '/admin/stats', null, A);
  ok(r.users >= 2 && r.questions === 15, 'stats');
  r = await api('GET', '/admin/users?search=test', null, A);
  ok(r.users.length >= 1 && r.users[0].plan === 'Pro', 'user search');
  const uid = r.users[0].id;
  r = await api('POST', `/admin/users/${uid}/ban`, {}, A);
  ok(r.banned === true, 'ban');
  r = await api('GET', '/me/dashboard', null, U);
  ok(r.status === 403, 'banned user locked out immediately');
  await api('POST', `/admin/users/${uid}/ban`, {}, A);
  r = await api('POST', '/admin/questions', { title: 'Add Two', diff: 'Easy', topic: 'Arrays', description: 'Add numbers', fnName: 'add', params: 'a, b', tests: '[{"args":[1,2],"expected":3},{"args":[5,5],"expected":10,"hidden":true}]' }, A);
  ok(r.id, 'admin creates question with tests');
  const nq = r.id;
  r = await api('POST', `/questions/${nq}/submit`, { code: 'function add(a,b){return a+b}', lang: 'JavaScript' }, A);
  ok(r.accepted, 'admin-created question is runnable');
  r = await api('POST', '/admin/questions', { title: 'x', diff: 'Easy', topic: 'Arrays', description: 'd', fnName: 'f', tests: 'not json' }, A);
  ok(r.status === 400, 'invalid test JSON rejected');
  r = await api('PUT', `/admin/questions/${nq}`, { title: 'Add Two Numbers', diff: 'Medium', topic: 'Arrays', description: 'Add', fnName: 'add', params: 'a, b', tests: '[{"args":[1,2],"expected":3}]' }, A);
  ok(r.ok, 'admin edits question');
  r = await api('DELETE', `/admin/questions/${nq}`, null, A);
  ok(r.ok, 'admin deletes question');
  r = await api('GET', '/admin/analytics', null, A);
  ok(r.top.length > 0 && r.weekly.length === 7 && r.weekly[6].val > 0, 'analytics from real data');

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
