'use strict';
/* PrepGrid frontend – talks to the Express API under /api */

// ===== helpers =====
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const COLORS = ['#6366f1', '#22c55e', '#ec4899', '#f59e0b', '#06b6d4', '#a855f7'];
const colorFor = (id) => COLORS[Math.abs(Number(id) || 0) % COLORS.length];
const PAGES = ['dashboard', 'practice', 'interview', 'quiz', 'billing', 'admin'];
const mmss = (s) => { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const fmtDate = (iso, o = { month: 'short', day: 'numeric' }) => new Date(iso).toLocaleDateString(undefined, o);
const scoreColor = (n) => (n >= 80 ? 'var(--green)' : n >= 65 ? 'var(--amber)' : 'var(--red)');
const md = (safeHtml) => safeHtml.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
let _deb; function debounce(fn) { clearTimeout(_deb); _deb = setTimeout(fn, 250); }

function ago(iso) {
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  if (s < 172800) return 'Yesterday';
  return Math.floor(s / 86400) + 'd ago';
}

let toastTimer;
function showToast(msg, isErr) {
  const t = $('toast');
  $('toast-msg').textContent = msg;
  $('toast-icon').textContent = isErr ? '⚠' : '✓';
  t.classList.toggle('err', !!isErr);
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
}

function setBusy(btn, busy, label) {
  if (!btn) return;
  if (busy) { btn.dataset.label = btn.innerHTML; btn.innerHTML = '<span class="spinner"></span>' + (label || ''); btn.disabled = true; }
  else { if (btn.dataset.label) btn.innerHTML = btn.dataset.label; btn.disabled = false; }
}

// ===== API =====
let token = localStorage.getItem('pg_token') || sessionStorage.getItem('pg_token') || null;
let me = null;

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null; try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    const e = new Error((data && data.error) || `Request failed (${res.status})`);
    e.status = res.status; e.data = data || {};
    if ((res.status === 401 || (res.status === 403 && /suspended/i.test(e.message))) && token) { logout(true, e.message); }
    throw e;
  }
  return data;
}
function fail(e) {
  if (!e || !token && e.status === 401) return;
  showToast(e.message || 'Something went wrong', true);
  if (e.status === 402 && e.data && e.data.upgrade) setTimeout(() => navigate('billing'), 1200);
}

// ===== state =====
const state = { page: 'dashboard', diff: 'all', topic: 'all', qlist: [], qtotal: 0, selected: null, drafts: {}, interview: null, quiz: null, billing: null };
let quizTimer = null, interviewTimer = null;

// ===== AUTH =====
function showAuthView(view) {
  ['login', 'register', 'forgot'].forEach((v) => { $('auth-' + v + '-view').style.display = v === view ? 'block' : 'none'; setAuthMsg(v, ''); });
}
function setAuthMsg(view, msg, info) {
  const el = $('err-' + view);
  el.textContent = msg || '';
  el.className = 'auth-error' + (msg ? ' show' : '') + (info ? ' auth-info' : '');
}
function showAuth() { $('main-app').style.display = 'none'; $('auth-page').style.display = 'block'; showAuthView('login'); }

function enterApp(user, tok, remember) {
  token = tok;
  localStorage.removeItem('pg_token'); sessionStorage.removeItem('pg_token');
  (remember ? localStorage : sessionStorage).setItem('pg_token', tok);
  me = user;
  $('auth-page').style.display = 'none';
  $('main-app').style.display = 'block';
  renderUserPill();
  const start = location.hash.slice(1);
  navigate(PAGES.includes(start) ? start : 'dashboard');
}

async function doLogin() {
  const email = $('login-email').value.trim(), password = $('login-pass').value;
  if (!email || !password) return setAuthMsg('login', 'Enter your email and password');
  setAuthMsg('login', ''); setBusy($('login-btn'), true, 'Signing in…');
  try { const r = await api('/auth/login', { method: 'POST', body: { email, password, remember: $('login-remember').checked } }); $('login-pass').value = ''; enterApp(r.user, r.token, $('login-remember').checked); }
  catch (e) { setAuthMsg('login', e.message); }
  finally { setBusy($('login-btn'), false); }
}
async function doRegister() {
  const body = { firstName: $('reg-first').value, lastName: $('reg-last').value, email: $('reg-email').value, password: $('reg-pass').value };
  setAuthMsg('register', ''); setBusy($('reg-btn'), true, 'Creating…');
  try { const r = await api('/auth/register', { method: 'POST', body }); $('reg-pass').value = ''; enterApp(r.user, r.token, true); showToast('Welcome to PrepGrid!'); }
  catch (e) { setAuthMsg('register', e.message); }
  finally { setBusy($('reg-btn'), false); }
}
let otpSent = false;
async function sendOTP() {
  const email = $('fg-email').value.trim();
  setAuthMsg('forgot', '');
  setBusy($('fg-btn'), true, otpSent ? 'Resetting…' : 'Sending…');
  try {
    if (!otpSent) {
      const r = await api('/auth/forgot', { method: 'POST', body: { email } });
      otpSent = true; $('otp-section').style.display = 'block'; $('fg-btn').dataset.label = 'Reset password';
      setAuthMsg('forgot', r.message + (r.devOtp ? ` (dev mode OTP: ${r.devOtp})` : ''), true);
    } else {
      await api('/auth/reset', { method: 'POST', body: { email, otp: $('fg-otp').value.trim(), newPassword: $('fg-pass').value } });
      otpSent = false; $('otp-section').style.display = 'none'; $('fg-btn').dataset.label = 'Send OTP';
      showAuthView('login'); $('login-email').value = email; setAuthMsg('login', 'Password updated. Sign in with your new password.', true);
    }
  } catch (e) { setAuthMsg('forgot', e.message); }
  finally { setBusy($('fg-btn'), false); }
}

function logout(silent, msg) {
  token = null; me = null;
  localStorage.removeItem('pg_token'); sessionStorage.removeItem('pg_token');
  clearInterval(quizTimer); clearInterval(interviewTimer);
  state.interview = null; state.quiz = null; state.selected = null; state.drafts = {};
  showAuth();
  if (msg) setAuthMsg('login', msg); else if (!silent) showToast('Signed out');
}

function renderUserPill() {
  $('u-avatar').textContent = me.initials;
  $('u-name').textContent = `${me.firstName} ${me.lastName}`.trim();
  $('u-plan').innerHTML = me.plan === 'Pro' ? 'Pro Plan <span class="pro-badge">PRO</span>' : 'Free Plan → <span class="pro-badge">PRO</span>';
  $('nav-admin').style.display = me.role === 'admin' ? 'flex' : 'none';
}

// ===== NAVIGATION =====
function navigate(page) {
  if (!PAGES.includes(page)) page = 'dashboard';
  if (page === 'admin' && (!me || me.role !== 'admin')) { showToast('Admin access required', true); page = 'dashboard'; }
  document.querySelectorAll('.page').forEach((p) => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach((n) => n.classList.remove('active'));
  $('page-' + page).classList.add('active');
  $('nav-' + page)?.classList.add('active');
  state.page = page;
  if (location.hash.slice(1) !== page) history.replaceState(null, '', '#' + page);
  const r = { dashboard: renderDashboard, practice: renderPractice, interview: renderInterviewSetup, quiz: renderQuizSetup, billing: renderBilling, admin: renderAdmin }[page];
  Promise.resolve(r()).catch(fail);
}
window.addEventListener('hashchange', () => { const p = location.hash.slice(1); if (me && PAGES.includes(p) && p !== state.page) navigate(p); });

// ===== DASHBOARD =====
async function renderDashboard() {
  const hr = new Date().getHours();
  $('greeting').textContent = `Good ${hr < 12 ? 'morning' : hr < 18 ? 'afternoon' : 'evening'}, ${me.firstName}`;
  const d = await api('/me/dashboard');
  const s = d.stats;
  $('st-solved').textContent = s.solved;
  $('st-solved-d').textContent = s.solvedWeek ? `↑ ${s.solvedWeek} this week` : '';
  $('st-int').textContent = s.interviews;
  $('st-int-d').textContent = s.interviewsMonth ? `↑ ${s.interviewsMonth} this month` : '';
  $('st-avg').textContent = s.avgScore == null ? '–' : s.avgScore + '%';
  $('st-avg-d').textContent = s.scoreCount ? `across ${s.scoreCount} interview/quiz result${s.scoreCount > 1 ? 's' : ''}` : 'Take a quiz or interview';
  $('st-streak').textContent = '🔥 ' + s.streak;
  $('st-streak-d').textContent = s.streak && s.streak >= s.bestStreak ? 'Personal best!' : '';
  $('topic-badge').textContent = `${s.solved} / ${s.totalQuestions}`;
  $('streak-month').textContent = d.month;
  $('streak-big').textContent = '🔥 ' + s.streak;
  $('streak-best').textContent = s.bestStreak + (s.bestStreak === 1 ? ' day' : ' days');

  const palette = ['var(--accent)', 'var(--green)', 'var(--amber)', 'var(--pink)', 'var(--cyan)', 'var(--green)', 'var(--accent2)'];
  $('topic-bars').innerHTML = d.topics.map((t, i) => `
    <div style="margin-bottom:12px;">
      <div class="flex-between" style="margin-bottom:6px;"><span class="text-sm">${esc(t.topic)}</span><span class="text-sm text-muted">${t.solved}/${t.total}</span></div>
      <div class="progress-bar"><div class="progress-fill" style="width:${Math.round((t.solved / t.total) * 100)}%;background:${palette[i % palette.length]};"></div></div>
    </div>`).join('') || '<div class="empty-state">No questions yet</div>';

  $('streak-grid').innerHTML = d.grid.map((g) => `<div class="streak-day ${g.state === 'done' ? 'done' : g.state === 'today' ? 'today' : g.state === 'missed' ? 'missed' : ''}" title="${esc(g.date)}"></div>`).join('');

  $('weak-areas').innerHTML = d.weak.length ? d.weak.map((w) => `
    <div style="margin-bottom:14px;">
      <div class="flex-between" style="margin-bottom:6px;"><span class="text-sm">${w.kind === 'quiz' ? '◈' : '⌨'} ${esc(w.topic)}</span><span class="text-sm" style="color:${scoreColor(w.score)};">${w.score}%</span></div>
      <div class="progress-bar"><div class="progress-fill" style="width:${w.score}%;background:${scoreColor(w.score)};"></div></div>
    </div>`).join('') : '<div class="empty-state" style="padding:20px;"><span style="font-size:13px;">Solve questions or take a quiz and your weakest topics show up here.</span></div>';

  const color = { solved: 'var(--green)', attempted: 'var(--text3)', interview: 'var(--amber)', quiz: 'var(--accent2)' };
  $('recent-activity').innerHTML = d.recent.length ? d.recent.map((r) => `
    <div class="flex-between" style="padding:8px 0;border-bottom:1px solid var(--border);">
      <div><div style="font-size:13px;font-weight:500;">${esc(r.title)}</div><div class="text-sm text-muted">${ago(r.at)}</div></div>
      <span style="font-size:12px;font-weight:600;color:${color[r.type] || 'var(--text2)'};">${esc(r.detail)}</span>
    </div>`).join('') : '<div class="empty-state" style="padding:20px;"><span style="font-size:13px;">No activity yet. Try your first question!</span></div>';
}

// ===== PRACTICE =====
const SORTS = ['default', 'easy', 'hard', 'solved'];
async function renderPractice() {
  await filterQuestions();
  if (!state.selected) {
    const first = state.qlist.find((q) => !q.locked);
    if (first) await loadQuestion(first.id);
  }
}

async function filterQuestions() {
  const p = new URLSearchParams({ search: $('q-search').value.trim(), diff: state.diff, topic: state.topic, sort: SORTS[$('sort-select').selectedIndex] || 'default' });
  const r = await api('/questions?' + p);
  state.qlist = r.questions; state.qtotal = r.total;
  renderQList();
}

function renderQList() {
  $('q-count').textContent = `Showing ${state.qlist.length} of ${state.qtotal} question${state.qtotal !== 1 ? 's' : ''}`;
  $('q-hint').textContent = me.plan === 'Free' ? '🔒 = Pro' : '';
  $('q-list').innerHTML = state.qlist.length ? state.qlist.map((q) => `
    <div class="q-item ${q.locked ? 'locked' : ''} ${state.selected && state.selected.id === q.id ? 'selected' : ''}" onclick="${q.locked ? 'lockedToast()' : `loadQuestion(${q.id})`}">
      <div class="q-check ${q.solved ? 'solved' : ''}">${q.solved ? '✓' : ''}</div>
      <div class="q-num">${q.id}.</div>
      <div class="q-title">${esc(q.title)}</div>
      <div class="q-meta">
        <span class="badge badge-topic" style="font-size:10px;">${esc(q.topic)}</span>
        <span class="badge badge-${esc(q.diff.toLowerCase())}" style="font-size:10px;">${esc(q.diff)}</span>
        ${q.locked ? '<span title="Pro only">🔒</span>' : `<button class="bookmark-btn ${q.bookmarked ? 'active' : ''}" onclick="event.stopPropagation();toggleBookmarkById(${q.id})">${q.bookmarked ? '★' : '☆'}</button>`}
      </div>
    </div>`).join('') : '<div class="empty-state"><span class="empty-icon">⌕</span>No questions match your filters</div>';
}
function lockedToast() { showToast('This question is available on the Pro plan', true); }

function toggleChip(el, type) {
  const group = type === 'diff' ? 'difficulty-chips' : 'topic-chips';
  document.querySelectorAll('#' + group + ' .chip').forEach((c) => c.classList.remove('active'));
  el.classList.add('active');
  state[type === 'diff' ? 'diff' : 'topic'] = el.dataset.val;
  filterQuestions().catch(fail);
}

const getCode = () => $('code-editor').innerText.replace(/\u00a0/g, ' ').replace(/\n$/, '');
function saveDraft() { if (state.selected) state.drafts[state.selected.id] = getCode(); }

async function loadQuestion(id) {
  saveDraft();
  let q;
  try { q = await api('/questions/' + id); } catch (e) { return fail(e); }
  state.selected = q;
  $('q-panel-title').textContent = q.title;
  $('q-panel-diff').textContent = q.diff;
  $('q-panel-diff').className = 'badge badge-' + q.diff.toLowerCase();
  $('q-panel-topic').textContent = q.topic;
  const ex = (q.examples || []).map((e, i) => `<div class="mt-8" style="font-family:var(--mono);font-size:12px;background:var(--bg3);border-radius:8px;padding:8px 10px;">Example ${i + 1}<br>Input: ${esc(JSON.stringify(e.input))}<br>Output: ${esc(JSON.stringify(e.expected))}</div>`).join('');
  $('q-panel-desc').innerHTML = esc(q.description) + ex;
  renderBookmarkBtn();
  $('code-editor').textContent = state.drafts[q.id] ?? q.lastCode ?? q.starter ?? '';
  const sel = $('lang-select');
  if (q.kind === 'sql') sel.value = 'SQL'; else if (sel.value === 'SQL') sel.value = 'JavaScript';
  $('editor-file').textContent = q.kind === 'sql' ? 'query.sql' : 'solution.js';
  $('run-output').style.display = 'none';
  $('runtime-stat').textContent = '—';
  renderQList();
}

function renderBookmarkBtn() {
  const q = state.selected; if (!q) return;
  const b = $('q-bookmark-btn');
  b.textContent = q.bookmarked ? '★ Bookmarked' : '☆ Bookmark';
  b.style.color = q.bookmarked ? 'var(--amber)' : '';
}
async function toggleBookmarkById(id) {
  try {
    const r = await api(`/questions/${id}/bookmark`, { method: 'POST' });
    const item = state.qlist.find((q) => q.id === id); if (item) item.bookmarked = r.bookmarked;
    if (state.selected && state.selected.id === id) { state.selected.bookmarked = r.bookmarked; renderBookmarkBtn(); }
    renderQList();
  } catch (e) { fail(e); }
}
function toggleBookmark() { if (state.selected) toggleBookmarkById(state.selected.id); }

function onLangChange() {
  const v = $('lang-select').value, q = state.selected;
  if (q && q.kind === 'sql' && v !== 'SQL') showToast('This is a SQL question. Select SQL to run it.', true);
  else if (q && q.kind !== 'sql' && v !== 'JavaScript') showToast(v === 'SQL' ? 'SQL only applies to SQL questions' : `${v} execution isn't enabled yet. JavaScript runs for real.`, true);
}

const fmt = (v) => { let s; try { s = JSON.stringify(v); } catch { s = String(v); } if (s === undefined) s = 'undefined'; return s.length > 140 ? s.slice(0, 140) + '…' : s; };

function renderRunOutput(r, submitted) {
  const out = $('run-output'); out.style.display = 'block';
  if (!r.ok) { out.innerHTML = `<span class="bad">✗ ${esc(r.error)}</span>` + (r.logs && r.logs.length ? `\n\n<span class="dim">Console:</span>\n${esc(r.logs.join('\n'))}` : ''); return; }
  const allOk = r.passed === r.total;
  let h = allOk ? `<span>✓ ${submitted ? 'Accepted – ' : ''}All ${r.total} test case${r.total > 1 ? 's' : ''} passed</span>\n\n` : `<span class="bad">✗ ${r.passed}/${r.total} test cases passed</span>\n\n`;
  h += r.results.map((t) => {
    const mark = t.passed ? '<span>✓</span>' : '<span class="bad">✗</span>';
    if (t.hidden) return `Hidden test ${t.n}  ${mark}${t.error ? ' <span class="bad">' + esc(t.error) + '</span>' : ''}`;
    const inp = t.input == null ? '' : `input=${esc(fmt(t.input))}  →  `;
    return `Test ${t.n}: ${inp}${t.error ? `<span class="bad">${esc(t.error)}</span>` : 'got ' + esc(fmt(t.got))}${t.passed ? '' : `  <span class="dim">(expected ${esc(fmt(t.expected))})</span>`}  ${mark}`;
  }).join('\n');
  if (r.logs && r.logs.length) h += `\n\n<span class="dim">Console:</span>\n${esc(r.logs.join('\n'))}`;
  out.innerHTML = h + `\n\n<span class="dim">Runtime: ${r.runtimeMs}ms</span>`;
  $('runtime-stat').textContent = r.runtimeMs + 'ms';
}

async function runCode(submit) {
  const q = state.selected; if (!q) return;
  saveDraft();
  const btn = submit ? document.querySelector('.editor-footer .btn-primary') : document.querySelector('.editor-footer .btn-secondary');
  setBusy(btn, true, submit ? 'Judging…' : 'Running…');
  try {
    const r = await api(`/questions/${q.id}/${submit ? 'submit' : 'run'}`, { method: 'POST', body: { code: getCode(), lang: $('lang-select').value } });
    renderRunOutput(r, submit);
    if (submit && r.ok) {
      if (r.accepted) {
        showToast(r.firstSolve ? '✓ Solution accepted! Question solved' : '✓ Accepted');
        const item = state.qlist.find((x) => x.id === q.id); if (item) item.solved = true;
        q.solved = true; renderQList();
      } else showToast(`${r.passed}/${r.total} tests passed`, true);
    }
  } catch (e) { fail(e); }
  finally { setBusy(btn, false); }
}
function submitCode() { return runCode(true); }

document.addEventListener('keydown', (e) => {                // Tab inserts spaces in the editor
  if (e.target && e.target.id === 'code-editor' && e.key === 'Tab') { e.preventDefault(); document.execCommand('insertText', false, '  '); }
});

// ===== INTERVIEW =====
async function renderInterviewSetup() {
  if (state.interview) { showInterviewView('session'); return; }
  showInterviewView('setup');
  const u = await api('/interview/usage');
  $('interview-usage').innerHTML = (u.pro ? '⚡ Pro plan: unlimited interviews.' : `⚡ Free tier: ${u.used}/${u.limit} interviews used this month. <span style="color:var(--text2);">Upgrade to Pro for unlimited sessions.</span>`)
    + `<br><span style="color:var(--text2);">Scoring: ${u.aiEnabled ? 'AI evaluation' : 'offline heuristic (server has no AI key)'}</span>`;
}
function showInterviewView(v) {
  $('interview-setup').style.display = v === 'setup' ? 'block' : 'none';
  $('interview-session').style.display = v === 'session' ? 'block' : 'none';
  $('interview-history').style.display = v === 'history' ? 'block' : 'none';
}

function appendChat(cls, html) {
  const c = $('chat-container');
  const d = document.createElement('div'); d.className = 'chat-msg ' + cls;
  d.innerHTML = `<div class="chat-bubble ${cls}">${html}</div>`;
  c.appendChild(d); c.scrollTop = c.scrollHeight;
}

async function startInterview() {
  const btn = document.querySelector('#interview-setup .btn-primary');
  setBusy(btn, true, 'Preparing…');
  try {
    const r = await api('/interview/start', { method: 'POST', body: {
      role: $('interview-role').value, difficulty: $('interview-diff').value, duration: parseInt($('interview-dur').value, 10), focus: $('interview-focus').value,
    } });
    clearInterval(interviewTimer);
    state.interview = { id: r.sessionId, total: r.total, index: 0, done: false, busy: false, endAt: Date.now() + r.durationSec * 1000 };
    $('chat-container').innerHTML = '';
    $('session-role-label').textContent = r.role + ' Interview';
    $('q-total').textContent = r.total; $('q-counter').textContent = 1;
    $('user-answer').value = ''; $('user-answer').disabled = false;
    showInterviewView('session');
    appendChat('ai', md(`Welcome to your ${esc(r.role)} mock interview! I'll ask you up to ${r.total} questions and adapt as we go. Take your time and explain your thinking.\n\n**Question 1:** ${esc(r.question)}`));
    tickInterview();
    interviewTimer = setInterval(tickInterview, 1000);
  } catch (e) { fail(e); }
  finally { setBusy(btn, false); }
}

function tickInterview() {
  const s = state.interview; if (!s) return;
  const left = Math.round((s.endAt - Date.now()) / 1000);
  $('interview-timer').textContent = mmss(left);
  if (left <= 0 && !s.done) { s.done = true; clearInterval(interviewTimer); api(`/interview/${s.id}/end`, { method: 'POST' }).catch(() => {}); appendChat('ai', "⏰ Time's up! Session saved."); showToast("Time's up – session saved"); }
}

function handleTurn(r) {
  const s = state.interview;
  let h = '';
  if (r.score != null) h += `<div class="score-chip">Score: ${r.score}/100</div><div class="difficulty-chip" style="margin:8px 0 6px;">💡 ${esc(r.feedback)}</div>`;
  if (r.skipped) h += '<em>Skipped.</em><br>';
  if (r.done) {
    s.done = true; clearInterval(interviewTimer);
    const avg = r.summary && r.summary.avgScore;
    h += `<br>🎉 Interview complete!${avg != null ? ` Average score: <strong>${avg}/100</strong>.` : ''} Review your session history for details.`;
    setTimeout(() => showToast('Interview complete! Session saved.'), 400);
  } else {
    s.index = r.next.index; $('q-counter').textContent = s.index + 1;
    h += `<br><strong>Question ${s.index + 1}:</strong> ${esc(r.next.question)}`;
  }
  appendChat('ai', h);
}

async function submitAnswer() {
  const s = state.interview; if (!s || s.busy) return;
  if (s.done) return showToast('This session is finished. Press End Session.', true);
  const ans = $('user-answer').value.trim();
  if (!ans) return showToast('Please write an answer first', true);
  const btn = document.querySelector('#interview-session .btn-primary');
  s.busy = true; setBusy(btn, true, 'Evaluating…');
  appendChat('user', esc(ans).replace(/\n/g, '<br>'));
  $('user-answer').value = '';
  try { handleTurn(await api(`/interview/${s.id}/answer`, { method: 'POST', body: { answer: ans } })); }
  catch (e) { $('user-answer').value = ans; if (e.status === 409) { s.done = true; appendChat('ai', esc(e.message)); } fail(e); }
  finally { s.busy = false; setBusy(btn, false); }
}

async function skipQuestion() {
  const s = state.interview; if (!s || s.busy || s.done) return;
  s.busy = true;
  try { handleTurn(await api(`/interview/${s.id}/skip`, { method: 'POST' })); } catch (e) { fail(e); } finally { s.busy = false; }
}

async function endInterview() {
  const s = state.interview;
  clearInterval(interviewTimer);
  if (s) {
    try { const r = await api(`/interview/${s.id}/end`, { method: 'POST' }); const a = r.summary && r.summary.avgScore; showToast(a != null ? `Session saved. Average score ${a}%` : 'Session ended'); } catch (e) { fail(e); }
  }
  state.interview = null;
  renderInterviewSetup().catch(fail);
}

async function showHistory() {
  try {
    const r = await api('/interview/history');
    showInterviewView('history');
    $('history-list').innerHTML = r.sessions.length ? r.sessions.map((s) => `
      <div class="card card-hover" style="margin-bottom:12px;" onclick="reviewSession(${s.id})">
        <div class="flex-between">
          <div><div class="fw-600">${esc(s.role)}</div><div class="text-sm text-muted">${fmtDate(s.date)} · ${s.answered} answered${s.minutes ? ' · ' + s.minutes + 'min' : ''}</div></div>
          <div style="text-align:right;">
            <div style="font-family:var(--display);font-size:22px;font-weight:700;color:${s.score == null ? 'var(--text3)' : scoreColor(s.score)};">${s.score == null ? '–' : s.score + '%'}</div>
            <button class="btn btn-secondary btn-sm">Review →</button>
          </div>
        </div>
      </div>`).join('') : '<div class="empty-state"><span class="empty-icon">◎</span>No finished sessions yet.</div>';
  } catch (e) { fail(e); }
}

async function reviewSession(id) {
  try {
    const r = await api(`/interview/${id}/review`);
    $('history-list').innerHTML = `<button class="btn btn-secondary btn-sm mb-16" onclick="showHistory()">← Back</button>
      <div class="fw-600 mb-16">${esc(r.session.role)} · ${fmtDate(r.session.date)} · ${r.session.score == null ? '–' : r.session.score + '%'}</div>` +
      r.turns.map((t) => `<div class="card" style="margin-bottom:12px;">
        <div class="fw-600" style="font-size:13px;margin-bottom:8px;">Q${t.idx + 1}. ${esc(t.question)}</div>
        ${t.skipped ? '<div class="text-sm text-muted">Skipped</div>' : t.answer ? `<div class="text-sm" style="color:var(--text2);white-space:pre-wrap;margin-bottom:8px;">${esc(t.answer)}</div>
        <span class="score-chip">Score: ${t.score}/100</span><div class="difficulty-chip">💡 ${esc(t.feedback)}</div>` : '<div class="text-sm text-muted">Not answered</div>'}</div>`).join('');
  } catch (e) { fail(e); }
}

let recog = null;
function toggleMic() {
  const btn = $('mic-btn');
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return showToast('Voice input is not supported in this browser', true);
  if (recog) { recog.stop(); return; }
  recog = new SR(); recog.continuous = true; recog.interimResults = false; recog.lang = 'en-US';
  recog.onresult = (ev) => { for (let i = ev.resultIndex; i < ev.results.length; i++) if (ev.results[i].isFinal) { const t = $('user-answer'); t.value = (t.value ? t.value + ' ' : '') + ev.results[i][0].transcript.trim(); } };
  recog.onend = () => { recog = null; btn.textContent = '🎙 Use Voice'; };
  recog.onerror = (ev) => { showToast('Voice error: ' + ev.error, true); };
  recog.start(); btn.textContent = '⏹ Stop Recording'; showToast('Listening…');
}

// ===== QUIZ =====
async function renderQuizSetup() {
  if (state.quiz && !state.quiz.finished) { showQuizView('active'); return; }
  showQuizView('setup');
  const t = await api('/quiz/topics');
  const sel = $('quiz-topic'), cur = sel.value;
  sel.innerHTML = t.topics.map((x) => `<option value="${esc(x.name)}">${esc(x.name)} · ${x.questions} Qs${t.aiEnabled ? '+' : ''}</option>`).join('');
  if (cur) sel.value = cur;
  $('quiz-usage').textContent = t.limit == null ? 'Pro: unlimited tests' : `Free tier: ${t.used}/${t.limit} tests used this month`;
  updateLeaderboard($('lb-topic').value);
}
function showQuizView(v) {
  $('quiz-setup').style.display = v === 'setup' ? 'block' : 'none';
  $('quiz-active').style.display = v === 'active' ? 'block' : 'none';
  $('quiz-results').style.display = v === 'results' ? 'block' : 'none';
}

async function updateLeaderboard(topic) {
  const box = $('leaderboard-list');
  try {
    const r = await api('/quiz/leaderboard?topic=' + encodeURIComponent(topic));
    box.innerHTML = r.entries.length ? r.entries.map((u, i) => `
      <div class="lb-row ${u.me ? 'me' : ''}">
        <div class="lb-rank ${['gold', 'silver', 'bronze'][i] || ''}">${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : i + 1}</div>
        <div class="lb-avatar" style="background:${colorFor(u.userId)};">${esc(u.avatar)}</div>
        <div style="flex:1;font-size:13px;font-weight:500;">${esc(u.name)}${u.me ? ' (you)' : ''}</div>
        <div class="lb-score" style="color:${i < 3 ? 'var(--amber)' : 'var(--text)'};">${u.score}</div>
      </div>`).join('') : '<div class="locked-note">No attempts on this topic yet. Be the first on the board!</div>';
  } catch (e) {
    box.innerHTML = e.status === 402 ? '<div class="locked-note">🔒 The leaderboard is a Pro feature.<br><button class="btn btn-primary btn-sm mt-12" onclick="navigate(\'billing\')">Upgrade to Pro</button></div>' : `<div class="locked-note">${esc(e.message)}</div>`;
  }
}

async function startQuiz() {
  const btn = $('quiz-start-btn'); setBusy(btn, true, 'Preparing test…');
  try {
    const r = await api('/quiz/start', { method: 'POST', body: { topic: $('quiz-topic').value, count: parseInt($('quiz-count').value, 10), timeMin: parseInt($('quiz-time').value, 10) } });
    state.quiz = { id: r.attemptId, topic: r.topic, questions: r.questions, qi: 0, answers: {}, finished: false, busy: false, endAt: Date.now() + r.timeLimitSec * 1000, startedAt: Date.now() };
    if (r.note) showToast(r.note);
    $('quiz-topic-label').textContent = r.topic;
    $('quiz-timer').style.color = 'var(--amber)';
    showQuizView('active');
    renderQuizQuestion(); tickQuiz();
    clearInterval(quizTimer); quizTimer = setInterval(tickQuiz, 1000);
  } catch (e) { fail(e); }
  finally { setBusy(btn, false); }
}

function tickQuiz() {
  const z = state.quiz; if (!z || z.finished) return;
  const left = Math.round((z.endAt - Date.now()) / 1000);
  $('quiz-timer').textContent = mmss(left);
  if (left <= 60) $('quiz-timer').style.color = 'var(--red)';
  if (left <= 0) { showToast("Time's up!", true); finishQuiz(); }
}

function renderQuizQuestion() {
  const z = state.quiz, q = z.questions[z.qi], a = z.answers[z.qi];
  $('quiz-q-num').textContent = z.qi + 1; $('quiz-q-total').textContent = z.questions.length;
  $('quiz-progress').style.width = Math.round((Object.keys(z.answers).length / z.questions.length) * 100) + '%';
  $('quiz-question-text').textContent = q.question;
  $('quiz-options').innerHTML = q.options.map((o, i) => {
    let cls = 'mcq-option';
    if (a) cls += i === a.correctIndex ? ' correct locked' : i === a.selected ? ' wrong locked' : ' locked';
    return `<div class="${cls}" onclick="selectOption(${i})"><div class="opt-letter">${'ABCD'[i]}</div>${esc(o)}</div>`;
  }).join('');
  const fb = $('quiz-feedback');
  if (a) {
    fb.style.display = 'block';
    fb.style.background = a.correct ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)';
    fb.style.border = `1px solid ${a.correct ? 'rgba(34,197,94,0.3)' : 'rgba(239,68,68,0.3)'}`;
    fb.style.color = a.correct ? 'var(--green)' : 'var(--red)';
    fb.textContent = (a.correct ? '✓ Correct! ' : '✗ Incorrect. ') + a.explanation;
  } else fb.style.display = 'none';
  $('next-btn').textContent = z.qi === z.questions.length - 1 ? 'Finish Test' : 'Next →';
}

async function selectOption(i) {
  const z = state.quiz; if (!z || z.finished || z.busy || z.answers[z.qi]) return;
  z.busy = true;
  try { z.answers[z.qi] = await api(`/quiz/${z.id}/answer`, { method: 'POST', body: { qIndex: z.qi, selected: i } }); renderQuizQuestion(); }
  catch (e) { fail(e); if (e.status === 409) finishQuiz(); }
  finally { z.busy = false; }
}
function nextQuestion() {
  const z = state.quiz; if (!z) return;
  if (z.qi < z.questions.length - 1) { z.qi++; renderQuizQuestion(); }
  else if (Object.keys(z.answers).length < z.questions.length && !confirm(`You answered ${Object.keys(z.answers).length} of ${z.questions.length}. Finish anyway?`)) return;
  else finishQuiz();
}
function prevQuestion() { const z = state.quiz; if (z && z.qi > 0) { z.qi--; renderQuizQuestion(); } }

async function finishQuiz() {
  const z = state.quiz; if (!z || z.finished) return;
  z.finished = true; clearInterval(quizTimer);
  try {
    const r = await api(`/quiz/${z.id}/finish`, { method: 'POST' });
    showQuizView('results');
    $('result-score').textContent = `${r.correct}/${r.total}`;
    $('r-correct').textContent = r.correct; $('r-wrong').textContent = r.wrong; $('r-time').textContent = mmss(r.timeUsedSec);
    $('result-emoji').textContent = r.pct >= 80 ? '🎯' : r.pct >= 60 ? '👍' : '📚';
    $('result-msg').textContent = r.percentile != null ? `You scored better than ${r.percentile}% of other attempts on this topic.` : r.pct >= 80 ? 'Excellent work!' : r.pct >= 60 ? 'Good effort! Review the questions you missed.' : "Keep practicing, you'll get there!";
    $('result-feedback').textContent = r.feedback;
  } catch (e) { fail(e); state.quiz = null; renderQuizSetup().catch(() => {}); }
}
function resetQuiz() { clearInterval(quizTimer); state.quiz = null; renderQuizSetup().catch(fail); }

// ===== BILLING =====
async function renderBilling() {
  const b = await api('/billing');
  state.billing = b; me = b.user; renderUserPill();
  const pro = me.plan === 'Pro';
  $('free-plan-btn').textContent = pro ? 'Free plan' : 'Current Plan';
  $('pro-btn').textContent = pro ? `Current Plan · extend 30 days (₹${b.price})` : `Upgrade to Pro → ₹${b.price}/mo`;
  $('pro-btn').disabled = b.mode === 'disabled';
  $('pro-btn').title = pro && me.planExpires && me.role !== 'admin' ? 'Pro active until ' + fmtDate(me.planExpires, { year: 'numeric', month: 'short', day: 'numeric' }) : '';
  $('billing-table').innerHTML = b.history.map((p) => `
    <tr><td>${fmtDate(p.date, { year: 'numeric', month: 'short', day: 'numeric' })}</td><td>${esc(p.description)}</td><td class="mono">₹${p.amount}</td>
    <td><span class="badge ${p.status === 'paid' ? 'badge-easy' : 'badge-hard'}">${esc(p.status)}</span></td><td class="mono text-muted" style="font-size:11px;">${esc(p.ref)}</td></tr>`).join('');
  $('billing-empty').style.display = b.history.length ? 'none' : 'block';
}

let pendingOrder = null;
async function openPayment() {
  const btn = $('pro-btn'); setBusy(btn, true, 'Starting…');
  try {
    const o = await api('/billing/order', { method: 'POST' });
    pendingOrder = o;
    if (o.mode === 'razorpay') {
      await loadScript('https://checkout.razorpay.com/v1/checkout.js');
      const rz = new window.Razorpay({
        key: o.keyId, order_id: o.orderId, amount: o.amount, currency: o.currency, name: 'PrepGrid', description: 'PrepGrid Pro – 1 month',
        prefill: { name: o.name, email: o.email }, theme: { color: '#6366f1' },
        handler: (resp) => verifyPayment({ orderId: resp.razorpay_order_id, paymentId: resp.razorpay_payment_id, signature: resp.razorpay_signature }),
      });
      rz.on('payment.failed', () => showToast('Payment failed. You were not charged.', true));
      rz.open();
    } else $('payment-modal').style.display = 'flex';
  } catch (e) { fail(e); }
  finally { setBusy(btn, false); }
}
function closePayment() { $('payment-modal').style.display = 'none'; }
function loadScript(src) {
  return new Promise((res, rej) => { if (document.querySelector(`script[src="${src}"]`)) return res(); const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('Could not load payment SDK')); document.head.appendChild(s); });
}
async function verifyPayment(body) {
  try { const r = await api('/billing/verify', { method: 'POST', body }); me = r.user; renderUserPill(); showToast('🎉 Upgraded to Pro! Welcome aboard!'); renderBilling().catch(() => {}); }
  catch (e) { fail(e); }
}
async function processPayment() {
  if (!pendingOrder) return;
  const btn = $('pay-btn'); setBusy(btn, true, 'Activating…');
  await verifyPayment({ orderId: pendingOrder.orderId, paymentId: 'sandbox' });
  setBusy(btn, false); closePayment(); pendingOrder = null;
}

// ===== ADMIN =====
async function renderAdmin() {
  const s = await api('/admin/stats');
  $('ad-users').textContent = s.users.toLocaleString(); $('ad-questions').textContent = s.questions.toLocaleString();
  $('ad-attempts').textContent = s.attemptsToday.toLocaleString(); $('ad-score').textContent = s.avgScore == null ? '–' : s.avgScore + '%';
  adminTab('questions');
}
function adminTab(tab) {
  document.querySelectorAll('#admin-tabs .tab').forEach((t) => t.classList.remove('active'));
  ['questions', 'users', 'analytics'].forEach((id) => { $('admin-' + id).style.display = 'none'; });
  document.querySelectorAll('#admin-tabs .tab')[['questions', 'users', 'analytics'].indexOf(tab)]?.classList.add('active');
  $('admin-' + tab).style.display = 'block';
  ({ questions: renderAdminQuestions, users: renderAdminUsers, analytics: renderAdminChart }[tab])().catch(fail);
}

async function renderAdminQuestions() {
  const r = await api('/admin/questions?search=' + encodeURIComponent($('admin-q-search').value.trim()));
  $('admin-q-table').innerHTML = r.questions.map((q) => `
    <tr>
      <td class="mono" style="color:var(--text3);">${q.id}</td>
      <td style="font-weight:500;">${esc(q.title)}</td>
      <td><span class="badge badge-topic">${esc(q.topic)}</span></td>
      <td><span class="badge badge-${esc(q.diff.toLowerCase())}">${esc(q.diff)}</span></td>
      <td class="mono">${q.attempts.toLocaleString()}</td>
      <td>${q.avgScore == null ? '<span class="text-muted">–</span>' : `<span style="color:${q.avgScore >= 70 ? 'var(--green)' : q.avgScore >= 50 ? 'var(--amber)' : 'var(--red)'};">${q.avgScore}%</span>`}</td>
      <td><div class="flex gap-8"><button class="btn btn-secondary btn-sm" onclick="editQuestion(${q.id})">Edit</button><button class="btn btn-danger btn-sm" onclick="deleteQuestion(${q.id})">Del</button></div></td>
    </tr>`).join('') || '<tr><td colspan="7" class="text-muted" style="text-align:center;padding:24px;">No questions</td></tr>';
}

async function renderAdminUsers() {
  const r = await api(`/admin/users?search=${encodeURIComponent($('admin-u-search').value.trim())}&plan=${$('admin-u-plan').value}`);
  $('admin-u-table').innerHTML = r.users.map((u) => `
    <tr>
      <td><div class="flex gap-8"><div class="lb-avatar" style="background:${colorFor(u.id)};width:28px;height:28px;font-size:11px;">${esc(u.avatar)}</div><span style="font-weight:500;">${esc(u.name)}</span>${u.role === 'admin' ? ' <span class="badge badge-topic">admin</span>' : ''}${u.banned ? ' <span class="badge badge-hard">suspended</span>' : ''}</div></td>
      <td style="color:var(--text2);">${esc(u.email)}</td>
      <td><span class="badge ${u.plan === 'Pro' ? 'badge-pro' : 'badge-topic'}">${esc(u.plan)}</span></td>
      <td class="mono">${u.solved}</td><td class="mono">${u.interviews}</td>
      <td>${u.score == null ? '<span class="text-muted">–</span>' : `<span style="color:${scoreColor(u.score)};">${u.score}%</span>`}</td>
      <td style="color:var(--text2);">${ago(u.lastActive)}</td>
      <td>${u.role === 'admin' ? '' : `<button class="btn ${u.banned ? 'btn-success' : 'btn-danger'} btn-sm" onclick="banUser(${u.id})">${u.banned ? 'Unban' : 'Ban'}</button>`}</td>
    </tr>`).join('') || '<tr><td colspan="8" class="text-muted" style="text-align:center;padding:24px;">No users found</td></tr>';
}
async function banUser(id) {
  try { const r = await api(`/admin/users/${id}/ban`, { method: 'POST' }); showToast(r.banned ? 'User suspended' : 'User reinstated'); renderAdminUsers(); } catch (e) { fail(e); }
}

async function renderAdminChart() {
  const r = await api('/admin/analytics');
  const colors = ['var(--accent)', 'var(--green)', 'var(--amber)', 'var(--pink)', 'var(--cyan)', 'var(--red)'];
  const bar = (label, val, pct, c, suffix = '') => `<div class="chart-bar-row"><div class="chart-bar-label" title="${esc(label)}" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(label)}</div><div class="chart-bar-track"><div class="chart-bar-fill" style="width:${Math.max(pct, 8)}%;background:${c};">${val}${suffix}</div></div></div>`;
  const max = Math.max(1, ...r.top.map((x) => x.val));
  $('admin-chart-q').innerHTML = r.top.length ? r.top.map((x, i) => bar(x.label, x.val.toLocaleString(), Math.round((x.val / max) * 100), colors[i % 6])).join('') : '<div class="empty-state" style="padding:20px;">No submissions yet</div>';
  $('admin-chart-score').innerHTML = r.topics.length ? r.topics.map((x) => bar(x.label, x.val, x.val, scoreColor(x.val), '%')).join('') : '<div class="empty-state" style="padding:20px;">No submissions yet</div>';
  const wmax = Math.max(1, ...r.weekly.map((w) => w.val));
  $('admin-sparkline').innerHTML = r.weekly.map((w) => `<div class="spark-bar" title="${w.val}" style="flex:1;height:${Math.max(4, Math.round((w.val / wmax) * 80))}px;background:var(--accent);border-radius:4px 4px 0 0;opacity:${0.5 + (w.val / wmax) * 0.5};"></div>`).join('');
  $('admin-spark-labels').innerHTML = r.weekly.map((w) => `<span class="text-sm text-muted">${esc(w.label)}</span>`).join('');
}

function onKindChange() {
  const sql = $('new-q-kind').value === 'sql';
  $('fg-fn').style.display = sql ? 'none' : 'block'; $('fg-sql').style.display = sql ? 'block' : 'none';
  $('new-q-tests').placeholder = sql ? '[{"expected": [["Asha", 70000, "Eng"]]}]' : '[{"args": [[2,7,11,15], 9], "expected": [0,1]}]';
}
function resetQuestionForm() {
  ['edit-q-id', 'new-q-title', 'new-q-tags', 'new-q-desc', 'new-q-fn', 'new-q-params', 'new-q-sql', 'new-q-tests'].forEach((i) => { $(i).value = ''; });
  $('new-q-kind').value = 'code'; $('new-q-diff').value = 'Easy'; onKindChange();
  $('q-form-title').textContent = 'Add New Question';
}
function showAddQuestion() {
  const f = $('add-q-form');
  if (f.style.display === 'none') { resetQuestionForm(); f.style.display = 'block'; } else f.style.display = 'none';
}
function hideQuestionForm() { $('add-q-form').style.display = 'none'; }

async function editQuestion(id) {
  try {
    const q = await api('/admin/questions/' + id);
    resetQuestionForm();
    $('edit-q-id').value = q.id; $('q-form-title').textContent = `Edit Question #${q.id}`;
    $('new-q-title').value = q.title; $('new-q-diff').value = q.diff; $('new-q-topic').value = q.topic; $('new-q-tags').value = q.tags;
    $('new-q-desc').value = q.description; $('new-q-kind').value = q.kind; $('new-q-fn').value = q.fnName; $('new-q-sql').value = q.sqlSetup; $('new-q-tests').value = q.tests;
    const m = /function\s+\w+\(([^)]*)\)/.exec(q.starter || ''); $('new-q-params').value = m ? m[1] : '';
    onKindChange(); $('add-q-form').style.display = 'block'; $('add-q-form').scrollIntoView({ behavior: 'smooth', block: 'center' });
  } catch (e) { fail(e); }
}
async function saveQuestion() {
  const id = $('edit-q-id').value;
  const body = { title: $('new-q-title').value, diff: $('new-q-diff').value, topic: $('new-q-topic').value, tags: $('new-q-tags').value, description: $('new-q-desc').value,
    kind: $('new-q-kind').value, fnName: $('new-q-fn').value, params: $('new-q-params').value, sqlSetup: $('new-q-sql').value, tests: $('new-q-tests').value };
  try {
    await api(id ? '/admin/questions/' + id : '/admin/questions', { method: id ? 'PUT' : 'POST', body });
    hideQuestionForm(); showToast(id ? 'Question updated' : 'Question added'); renderAdminQuestions(); api('/admin/stats').then((s) => { $('ad-questions').textContent = s.questions; });
  } catch (e) { fail(e); }
}
async function deleteQuestion(id) {
  if (!confirm(`Delete question #${id} and all submissions for it? This cannot be undone.`)) return;
  try { await api('/admin/questions/' + id, { method: 'DELETE' }); showToast('Question deleted'); if (state.selected && state.selected.id === id) state.selected = null; renderAdminQuestions(); api('/admin/stats').then((s) => { $('ad-questions').textContent = s.questions; }); } catch (e) { fail(e); }
}

// ===== BOOT =====
['login-email', 'login-pass'].forEach((id) => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') doLogin(); }));
['reg-first', 'reg-last', 'reg-email', 'reg-pass'].forEach((id) => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') doRegister(); }));
['fg-email', 'fg-otp', 'fg-pass'].forEach((id) => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') sendOTP(); }));
window.addEventListener('unhandledrejection', (e) => { e.preventDefault(); fail(e.reason); });

(async function boot() {
  if (!token) return showAuth();
  try { const r = await api('/auth/me'); enterApp(r.user, token, !!localStorage.getItem('pg_token')); }
  catch { showAuth(); }
})();
