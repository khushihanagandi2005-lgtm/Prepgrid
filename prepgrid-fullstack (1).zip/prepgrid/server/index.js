require('dotenv').config();
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

require('./lib');                       // validates JWT secret early
const db = require('./db');
const { seedIfEmpty } = require('./seed');
const billing = require('./routes/billing');

seedIfEmpty();

const app = express();
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || process.env.TRUST_PROXY);

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: false,
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", 'https://checkout.razorpay.com'],
      scriptSrcAttr: ["'unsafe-inline'"],            // the UI uses inline onclick handlers
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'https://*.razorpay.com'],
      connectSrc: ["'self'", 'https://*.razorpay.com'],
      frameSrc: ['https://api.razorpay.com', 'https://checkout.razorpay.com'],
      objectSrc: ["'none'"], baseUri: ["'self'"], frameAncestors: ["'self'"],
    },
  },
}));
if (process.env.CORS_ORIGIN) app.use('/api', cors({ origin: process.env.CORS_ORIGIN.split(','), credentials: false }));

// Webhook needs the raw body, so it is mounted before express.json()
app.post('/api/billing/webhook', express.raw({ type: '*/*', limit: '200kb' }), billing.webhook);
app.use(express.json({ limit: '100kb' }));

const authLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Try again in a few minutes.' } });
const apiLimiter = rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false });
app.use('/api', apiLimiter);

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));
app.use('/api/auth', authLimiter, require('./routes/auth'));
app.use('/api/questions', require('./routes/questions'));
app.use('/api/interview', require('./routes/interview'));
app.use('/api/quiz', require('./routes/quiz'));
app.use('/api/billing', billing.router);
app.use('/api/me', require('./routes/me'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

app.use(express.static(path.join(__dirname, '..', 'public'), { extensions: ['html'] }));
app.use((req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.use((err, req, res, next) => {          // eslint-disable-line no-unused-vars
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request too large' });
  console.error('[error]', err);
  res.status(500).json({ error: 'Something went wrong on our side' });
});

const PORT = Number(process.env.PORT) || 3000;
if (require.main === module) {
  const server = app.listen(PORT, () => console.log(`PrepGrid running → http://localhost:${PORT}`));
  const stop = () => { server.close(() => { db.close(); process.exit(0); }); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
module.exports = app;
