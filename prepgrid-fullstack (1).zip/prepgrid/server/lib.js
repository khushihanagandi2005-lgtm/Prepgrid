const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const db = require('./db');

// ---- JWT secret: env var, else persisted random secret (so dev sessions survive restarts) ----
function loadSecret() {
  if (process.env.JWT_SECRET) return process.env.JWT_SECRET;
  if (process.env.NODE_ENV === 'production') throw new Error('JWT_SECRET must be set in production');
  const f = path.join(__dirname, '..', 'data', '.jwt_secret');
  try { return fs.readFileSync(f, 'utf8'); } catch {
    const s = crypto.randomBytes(48).toString('hex');
    fs.writeFileSync(f, s, { mode: 0o600 });
    return s;
  }
}
const SECRET = loadSecret();

const LIMITS = { freeInterviewsPerMonth: 5, freeQuizzesPerMonth: 3, freeQuestions: 10 };
const PRO_PRICE_PAISE = 49900;

const iso = (s) => (s ? String(s).replace(' ', 'T') + 'Z' : null);
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function signToken(user, remember) {
  return jwt.sign({ uid: user.id }, SECRET, { expiresIn: remember ? '30d' : '1d' });
}

function isPro(u) {
  if (!u) return false;
  if (u.role === 'admin') return true;
  if (u.plan !== 'Pro') return false;
  if (u.plan_expires && new Date(iso(u.plan_expires)) < new Date()) {
    db.prepare("UPDATE users SET plan='Free', plan_expires=NULL WHERE id=?").run(u.id);
    u.plan = 'Free';
    return false;
  }
  return true;
}

function publicUser(u) {
  const pro = isPro(u);
  return {
    id: u.id, firstName: u.first_name, lastName: u.last_name, email: u.email, role: u.role,
    plan: pro ? 'Pro' : 'Free', planExpires: iso(u.plan_expires),
    initials: ((u.first_name[0] || '') + (u.last_name[0] || u.first_name[1] || '')).toUpperCase(),
  };
}

function requireAuth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Not authenticated' });
  try {
    const { uid } = jwt.verify(token, SECRET);
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(uid);
    if (!u) return res.status(401).json({ error: 'Account not found' });
    if (u.banned) return res.status(403).json({ error: 'This account has been suspended' });
    req.user = u;
    req.pro = isPro(u);
    db.prepare("UPDATE users SET last_active = datetime('now') WHERE id = ? AND last_active < datetime('now','-1 minute')").run(uid);
    next();
  } catch {
    res.status(401).json({ error: 'Session expired, please sign in again' });
  }
}

function requireAdmin(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
  next();
}

function requirePro(req, res, next) {
  if (!req.pro) return res.status(402).json({ error: 'This feature requires a Pro plan', upgrade: true });
  next();
}

function logActivity(userId, type, title, detail = '') {
  db.prepare('INSERT INTO activity_log (user_id,type,title,detail) VALUES (?,?,?,?)').run(userId, type, title, detail);
}

module.exports = { LIMITS, PRO_PRICE_PAISE, iso, wrap, signToken, isPro, publicUser, requireAuth, requireAdmin, requirePro, logActivity };
