const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { PRO_PRICE_PAISE, wrap, iso, requireAuth, publicUser } = require('../lib');

const router = express.Router();

const rzp = () => (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET ? { id: process.env.RAZORPAY_KEY_ID, secret: process.env.RAZORPAY_KEY_SECRET } : null);
const sandboxAllowed = () => process.env.NODE_ENV !== 'production' || process.env.ALLOW_SANDBOX_PAYMENTS === 'true';
const sqlTime = (d) => d.toISOString().slice(0, 19).replace('T', ' ');

// Idempotent: marks payment paid and extends Pro by 30 days
function markPaid(orderId, paymentId) {
  return db.transaction(() => {
    const p = db.prepare('SELECT * FROM payments WHERE order_id=?').get(orderId);
    if (!p) return null;
    if (p.status === 'paid') return p;
    db.prepare("UPDATE payments SET status='paid', payment_id=? WHERE id=?").run(paymentId, p.id);
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(p.user_id);
    const base = u.plan === 'Pro' && u.plan_expires && new Date(iso(u.plan_expires)) > new Date() ? new Date(iso(u.plan_expires)) : new Date();
    base.setUTCDate(base.getUTCDate() + 30);
    db.prepare("UPDATE users SET plan='Pro', plan_expires=? WHERE id=?").run(sqlTime(base), u.id);
    return p;
  })();
}

router.get('/', requireAuth, wrap((req, res) => {
  const history = db.prepare("SELECT order_id, amount_paise, status, description, created_at FROM payments WHERE user_id=? AND status != 'created' ORDER BY id DESC LIMIT 50").all(req.user.id)
    .map((p) => ({ ref: p.order_id, amount: p.amount_paise / 100, status: p.status, description: p.description, date: iso(p.created_at) }));
  res.json({
    user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)),
    history, price: PRO_PRICE_PAISE / 100,
    mode: rzp() ? 'razorpay' : sandboxAllowed() ? 'sandbox' : 'disabled',
    keyId: rzp()?.id || null,
  });
}));

router.post('/order', requireAuth, wrap(async (req, res) => {
  const keys = rzp();
  if (!keys && !sandboxAllowed()) return res.status(503).json({ error: 'Payments are not configured on this server.' });
  let orderId;
  if (keys) {
    const r = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: 'Basic ' + Buffer.from(`${keys.id}:${keys.secret}`).toString('base64') },
      body: JSON.stringify({ amount: PRO_PRICE_PAISE, currency: 'INR', receipt: `pg_${req.user.id}_${Date.now()}`, notes: { userId: String(req.user.id) } }),
    });
    if (!r.ok) { console.error('[razorpay]', r.status, await r.text()); return res.status(502).json({ error: 'Could not start payment. Try again.' }); }
    orderId = (await r.json()).id;
  } else {
    orderId = 'sandbox_' + crypto.randomBytes(8).toString('hex');
  }
  db.prepare('INSERT INTO payments (user_id,provider,order_id,amount_paise) VALUES (?,?,?,?)').run(req.user.id, keys ? 'razorpay' : 'sandbox', orderId, PRO_PRICE_PAISE);
  res.json({ mode: keys ? 'razorpay' : 'sandbox', orderId, amount: PRO_PRICE_PAISE, currency: 'INR', keyId: keys?.id || null, name: `${req.user.first_name} ${req.user.last_name}`.trim(), email: req.user.email });
}));

router.post('/verify', requireAuth, wrap((req, res) => {
  const { orderId, paymentId, signature } = req.body || {};
  const p = db.prepare('SELECT * FROM payments WHERE order_id=? AND user_id=?').get(String(orderId || ''), req.user.id);
  if (!p) return res.status(404).json({ error: 'Order not found' });
  if (p.provider === 'razorpay') {
    const expected = crypto.createHmac('sha256', rzp().secret).update(`${orderId}|${paymentId}`).digest('hex');
    const a = Buffer.from(expected), b = Buffer.from(String(signature || ''));
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      db.prepare("UPDATE payments SET status='failed' WHERE id=? AND status='created'").run(p.id);
      return res.status(400).json({ error: 'Payment verification failed' });
    }
    markPaid(orderId, paymentId);
  } else {
    if (!sandboxAllowed()) return res.status(403).json({ error: 'Sandbox payments disabled' });
    markPaid(orderId, 'sandbox_pay_' + crypto.randomBytes(6).toString('hex'));
  }
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)) });
}));

// Razorpay webhook (safety net if the browser closes before /verify). Mounted with express.raw() in index.js.
function webhook(req, res) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret) return res.status(404).end();
  const sig = String(req.headers['x-razorpay-signature'] || '');
  const expected = crypto.createHmac('sha256', secret).update(req.body).digest('hex');
  const a = Buffer.from(expected), b = Buffer.from(sig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(400).end();
  try {
    const ev = JSON.parse(req.body.toString('utf8'));
    if (ev.event === 'payment.captured') {
      const pay = ev.payload.payment.entity;
      markPaid(pay.order_id, pay.id);
    }
  } catch (e) { console.error('[webhook]', e.message); }
  res.json({ ok: true });
}

module.exports = { router, webhook };
