const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const db = require('../db');
const { wrap, signToken, publicUser, requireAuth } = require('../lib');

const router = express.Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const str = (v, max = 120) => String(v ?? '').trim().slice(0, max);

router.post('/register', wrap(async (req, res) => {
  const first = str(req.body.firstName, 60), last = str(req.body.lastName, 60);
  const email = str(req.body.email, 200).toLowerCase(), password = String(req.body.password || '');
  if (!first) return res.status(400).json({ error: 'First name is required' });
  if (!EMAIL_RE.test(email)) return res.status(400).json({ error: 'Enter a valid email address' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  if (password.length > 72) return res.status(400).json({ error: 'Password is too long (max 72 characters)' });
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) return res.status(409).json({ error: 'An account with this email already exists' });
  const info = db.prepare('INSERT INTO users (first_name,last_name,email,password_hash) VALUES (?,?,?,?)')
    .run(first, last, email, await bcrypt.hash(password, 10));
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ token: signToken(user, true), user: publicUser(user) });
}));

router.post('/login', wrap(async (req, res) => {
  const email = str(req.body.email, 200).toLowerCase(), password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  // Same error + same work whether the email exists or not
  const ok = await bcrypt.compare(password, user ? user.password_hash : '$2a$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidinv');
  if (!user || !ok) return res.status(401).json({ error: 'Incorrect email or password' });
  if (user.banned) return res.status(403).json({ error: 'This account has been suspended' });
  res.json({ token: signToken(user, !!req.body.remember), user: publicUser(user) });
}));

async function sendOtpEmail(email, otp) {
  if (!process.env.SMTP_HOST) return false;
  const t = nodemailer.createTransport({
    host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
  });
  await t.sendMail({
    from: process.env.MAIL_FROM || 'PrepGrid <no-reply@prepgrid.local>', to: email,
    subject: 'Your PrepGrid password reset code',
    text: `Your PrepGrid verification code is ${otp}. It expires in 10 minutes. If you did not request this, ignore this email.`,
  });
  return true;
}

router.post('/forgot', wrap(async (req, res) => {
  const email = str(req.body.email, 200).toLowerCase();
  if (!EMAIL_RE.test(email)) return res.status(400).json({ error: 'Enter a valid email address' });
  const out = { message: 'If an account exists for that email, a 6-digit OTP has been sent.' };
  const user = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (user) {
    const otp = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    db.prepare('INSERT OR REPLACE INTO reset_otps (email,otp_hash,expires_at,attempts) VALUES (?,?,?,0)')
      .run(email, sha(otp), Date.now() + 10 * 60 * 1000);
    let sent = false;
    try { sent = await sendOtpEmail(email, otp); } catch (e) { console.error('[mail] failed:', e.message); }
    if (!sent && process.env.NODE_ENV !== 'production') {
      console.log(`[dev] Password reset OTP for ${email}: ${otp}`);
      out.devOtp = otp;                     // only when no SMTP is configured and not in production
    }
  }
  res.json(out);
}));

router.post('/reset', wrap(async (req, res) => {
  const email = str(req.body.email, 200).toLowerCase(), otp = str(req.body.otp, 6), pw = String(req.body.newPassword || '');
  if (pw.length < 8 || pw.length > 72) return res.status(400).json({ error: 'Password must be 8-72 characters' });
  const row = db.prepare('SELECT * FROM reset_otps WHERE email = ?').get(email);
  if (!row || row.expires_at < Date.now() || row.attempts >= 5) return res.status(400).json({ error: 'OTP expired or invalid. Request a new one.' });
  const a = Buffer.from(sha(otp)), b = Buffer.from(row.otp_hash);
  if (!crypto.timingSafeEqual(a, b)) {
    db.prepare('UPDATE reset_otps SET attempts = attempts + 1 WHERE email = ?').run(email);
    return res.status(400).json({ error: 'Incorrect OTP' });
  }
  db.prepare('UPDATE users SET password_hash = ? WHERE email = ?').run(await bcrypt.hash(pw, 10), email);
  db.prepare('DELETE FROM reset_otps WHERE email = ?').run(email);
  res.json({ message: 'Password updated. You can now sign in.' });
}));

router.get('/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

module.exports = router;
