const express = require('express');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { LIMITS, wrap, requireAuth, logActivity } = require('../lib');
const { runJS, runSQL } = require('../exec');

const router = express.Router();
router.use(requireAuth);

const runLimiter = rateLimit({ windowMs: 60_000, limit: Number(process.env.RUN_RATE_LIMIT) || 30, keyGenerator: (req) => 'u' + req.user.id, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many runs, slow down a little.' } });

// First N questions (by id) are free; the rest need Pro
function freeIds() {
  return new Set(db.prepare('SELECT id FROM questions ORDER BY id LIMIT ?').all(LIMITS.freeQuestions).map((r) => r.id));
}

router.get('/', wrap((req, res) => {
  const { search = '', diff = 'all', topic = 'all', sort = 'default' } = req.query;
  const rows = db.prepare(`
    SELECT q.id, q.title, q.diff, q.topic, q.kind,
      COALESCE(uq.solved,0) AS solved, COALESCE(uq.bookmarked,0) AS bookmarked,
      (SELECT COUNT(*) FROM submissions s WHERE s.question_id = q.id) AS attempts,
      (SELECT COUNT(*) FROM user_questions x WHERE x.question_id = q.id AND x.solved = 1) AS solvers
    FROM questions q LEFT JOIN user_questions uq ON uq.question_id = q.id AND uq.user_id = ?
    ORDER BY q.id`).all(req.user.id);
  const free = freeIds();
  let list = rows.filter((r) =>
    (diff === 'all' || r.diff === diff) && (topic === 'all' || r.topic === topic) &&
    (!search || r.title.toLowerCase().includes(String(search).toLowerCase()) || r.topic.toLowerCase().includes(String(search).toLowerCase())))
    .map((r) => ({ ...r, solved: !!r.solved, bookmarked: !!r.bookmarked, locked: !req.pro && !free.has(r.id) }));
  const order = { Easy: 0, Medium: 1, Hard: 2 };
  if (sort === 'easy') list.sort((a, b) => order[a.diff] - order[b.diff] || a.id - b.id);
  else if (sort === 'hard') list.sort((a, b) => order[b.diff] - order[a.diff] || a.id - b.id);
  else if (sort === 'solved') list.sort((a, b) => b.solvers - a.solvers || a.id - b.id);
  res.json({ questions: list, total: rows.length });
}));

function loadQuestion(req, res) {
  const q = db.prepare('SELECT * FROM questions WHERE id = ?').get(Number(req.params.id));
  if (!q) { res.status(404).json({ error: 'Question not found' }); return null; }
  if (!req.pro && !freeIds().has(q.id)) { res.status(402).json({ error: 'This question is available on the Pro plan', upgrade: true }); return null; }
  return q;
}

router.get('/:id', wrap((req, res) => {
  const q = loadQuestion(req, res); if (!q) return;
  const uq = db.prepare('SELECT solved, bookmarked FROM user_questions WHERE user_id=? AND question_id=?').get(req.user.id, q.id) || {};
  const spec = q.tests ? JSON.parse(q.tests) : { cases: [] };
  const last = db.prepare("SELECT code FROM submissions WHERE user_id=? AND question_id=? ORDER BY id DESC LIMIT 1").get(req.user.id, q.id);
  res.json({
    id: q.id, title: q.title, diff: q.diff, topic: q.topic, tags: q.tags, description: q.description, kind: q.kind,
    starter: q.starter_js, lastCode: last ? last.code : null,
    solved: !!uq.solved, bookmarked: !!uq.bookmarked,
    examples: q.kind === 'sql' ? [] : spec.cases.filter((c) => !c.hidden).slice(0, 2).map((c) => ({ input: c.args, expected: c.expected })),
  });
}));

router.post('/:id/bookmark', wrap((req, res) => {
  const q = db.prepare('SELECT id FROM questions WHERE id = ?').get(Number(req.params.id));
  if (!q) return res.status(404).json({ error: 'Question not found' });
  db.prepare('INSERT OR IGNORE INTO user_questions (user_id,question_id) VALUES (?,?)').run(req.user.id, q.id);
  db.prepare('UPDATE user_questions SET bookmarked = 1 - bookmarked WHERE user_id=? AND question_id=?').run(req.user.id, q.id);
  const r = db.prepare('SELECT bookmarked FROM user_questions WHERE user_id=? AND question_id=?').get(req.user.id, q.id);
  res.json({ bookmarked: !!r.bookmarked });
}));

async function execute(q, code, lang, visibleOnly) {
  if (!q.tests) return { error: 'This question has no automated tests yet.' };
  if (q.kind === 'sql') {
    if (lang !== 'SQL') return { error: 'This is a SQL question. Select "SQL" as the language.' };
    const spec = JSON.parse(q.tests);
    const r = runSQL(code, q.sql_setup, spec.cases[0].expected);
    if (!r.ok) return { error: r.error };
    return { results: [{ passed: r.passed, ms: r.ms, got: r.rows, expected: r.expected, input: null }], logs: [] };
  }
  if (lang !== 'JavaScript') return { error: `${lang} execution is not enabled in this build. Please use JavaScript (see README to plug in Judge0 for more languages).` };
  const spec = JSON.parse(q.tests);
  const cases = visibleOnly ? spec.cases.filter((c) => !c.hidden) : spec.cases;
  const r = await runJS({ code, fn: q.fn_name, mode: spec.mode, cases });
  if (!r.ok) return { error: r.error, logs: r.logs };
  return { results: r.results, logs: r.logs };
}

function shape(results) {
  // never leak hidden test inputs/expected values
  return results.map((r, i) => r.hidden
    ? { n: i + 1, hidden: true, passed: r.passed, error: r.error ? 'Runtime error / timeout' : undefined, ms: r.ms }
    : { n: i + 1, hidden: false, passed: r.passed, input: r.input, expected: r.expected, got: r.got, error: r.error, ms: r.ms });
}

function validateBody(req, res) {
  const code = String(req.body.code ?? ''), lang = String(req.body.lang || 'JavaScript');
  if (!code.trim()) { res.status(400).json({ error: 'Write some code first' }); return null; }
  if (code.length > 20000) { res.status(400).json({ error: 'Code is too long (max 20,000 characters)' }); return null; }
  return { code, lang };
}

router.post('/:id/run', runLimiter, wrap(async (req, res) => {
  const q = loadQuestion(req, res); if (!q) return;
  const b = validateBody(req, res); if (!b) return;
  const r = await execute(q, b.code, b.lang, true);
  if (r.error) return res.json({ ok: false, error: r.error, logs: r.logs || [] });
  const passed = r.results.filter((x) => x.passed).length;
  res.json({ ok: true, passed, total: r.results.length, runtimeMs: Math.round(r.results.reduce((s, x) => s + x.ms, 0)), results: shape(r.results), logs: r.logs });
}));

router.post('/:id/submit', runLimiter, wrap(async (req, res) => {
  const q = loadQuestion(req, res); if (!q) return;
  const b = validateBody(req, res); if (!b) return;
  const r = await execute(q, b.code, b.lang, false);
  if (r.error) return res.json({ ok: false, error: r.error, logs: r.logs || [] });
  const passed = r.results.filter((x) => x.passed).length, total = r.results.length;
  const accepted = passed === total;
  const runtime = Math.round(r.results.reduce((s, x) => s + x.ms, 0));
  db.prepare('INSERT INTO submissions (user_id,question_id,lang,code,passed,total,runtime_ms) VALUES (?,?,?,?,?,?,?)')
    .run(req.user.id, q.id, b.lang, b.code, passed, total, runtime);
  db.prepare('INSERT OR IGNORE INTO user_questions (user_id,question_id) VALUES (?,?)').run(req.user.id, q.id);
  const was = db.prepare('SELECT solved FROM user_questions WHERE user_id=? AND question_id=?').get(req.user.id, q.id).solved;
  let firstSolve = false;
  if (accepted && !was) {
    db.prepare('UPDATE user_questions SET solved = 1 WHERE user_id=? AND question_id=?').run(req.user.id, q.id);
    firstSolve = true;
  }
  logActivity(req.user.id, accepted ? 'solved' : 'attempted', q.title, accepted ? 'Solved' : `${passed}/${total} tests`);
  res.json({ ok: true, accepted, firstSolve, passed, total, runtimeMs: runtime, results: shape(r.results), logs: r.logs });
}));

module.exports = router;
