const express = require('express');
const db = require('../db');
const { wrap, iso, requireAuth } = require('../lib');

const router = express.Router();
router.use(requireAuth);

const dayStr = (d) => d.toISOString().slice(0, 10);

router.get('/dashboard', wrap((req, res) => {
  const uid = req.user.id;

  // --- headline stats ---
  const solved = db.prepare('SELECT COUNT(*) c FROM user_questions WHERE user_id=? AND solved=1').get(uid).c;
  const totalQ = db.prepare('SELECT COUNT(*) c FROM questions').get().c;
  const solvedWeek = db.prepare("SELECT COUNT(*) c FROM activity_log WHERE user_id=? AND type='solved' AND created_at >= datetime('now','-7 days')").get(uid).c;
  const interviews = db.prepare("SELECT COUNT(*) c FROM interview_sessions WHERE user_id=? AND status='completed'").get(uid).c;
  const interviewsMonth = db.prepare("SELECT COUNT(*) c FROM interview_sessions WHERE user_id=? AND status='completed' AND started_at >= date('now','start of month')").get(uid).c;
  const scores = [
    ...db.prepare('SELECT avg_score s FROM interview_sessions WHERE user_id=? AND avg_score IS NOT NULL').all(uid).map((r) => r.s),
    ...db.prepare("SELECT correct*100.0/total s FROM quiz_attempts WHERE user_id=? AND status='finished' AND total>0").all(uid).map((r) => r.s),
  ];
  const avgScore = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;

  // --- streak ---
  const days = new Set(db.prepare('SELECT DISTINCT date(created_at) d FROM activity_log WHERE user_id=?').all(uid).map((r) => r.d));
  const today = new Date();
  const cur = (() => {
    let n = 0; const d = new Date(today);
    if (!days.has(dayStr(d))) d.setUTCDate(d.getUTCDate() - 1);   // today not done yet doesn't break the streak
    while (days.has(dayStr(d))) { n++; d.setUTCDate(d.getUTCDate() - 1); }
    return n;
  })();
  const sorted = [...days].sort();
  let best = 0, run = 0, prev = null;
  for (const s of sorted) {
    run = prev && (new Date(s) - new Date(prev)) / 864e5 === 1 ? run + 1 : 1;
    best = Math.max(best, run); prev = s;
  }
  const joined = dayStr(new Date(iso(req.user.created_at)));
  const grid = [];
  for (let i = 27; i >= 0; i--) {
    const d = new Date(today); d.setUTCDate(d.getUTCDate() - i);
    const k = dayStr(d);
    grid.push({ date: k, state: days.has(k) ? 'done' : i === 0 ? 'today' : k < joined ? 'empty' : 'missed' });
  }

  // --- topic mastery + weak areas ---
  const topics = db.prepare(`
    SELECT q.topic, COUNT(*) total, SUM(COALESCE(uq.solved,0)) solved
    FROM questions q LEFT JOIN user_questions uq ON uq.question_id=q.id AND uq.user_id=?
    GROUP BY q.topic ORDER BY q.topic`).all(uid);
  const codeWeak = db.prepare(`
    SELECT q.topic, ROUND(AVG(s.passed*100.0/s.total)) score
    FROM submissions s JOIN questions q ON q.id=s.question_id WHERE s.user_id=? GROUP BY q.topic`).all(uid)
    .map((r) => ({ topic: r.topic, score: r.score, kind: 'practice' }));
  const quizWeak = db.prepare(`
    SELECT topic, ROUND(AVG(correct*100.0/total)) score FROM quiz_attempts
    WHERE user_id=? AND status='finished' AND total>0 GROUP BY topic`).all(uid)
    .map((r) => ({ topic: r.topic, score: r.score, kind: 'quiz' }));
  const weak = [...codeWeak, ...quizWeak].sort((a, b) => a.score - b.score).slice(0, 3);

  const recent = db.prepare('SELECT type, title, detail, created_at FROM activity_log WHERE user_id=? ORDER BY id DESC LIMIT 6').all(uid)
    .map((r) => ({ type: r.type, title: r.title, detail: r.detail, at: iso(r.created_at) }));

  res.json({
    stats: { solved, totalQuestions: totalQ, solvedWeek, interviews, interviewsMonth, avgScore, scoreCount: scores.length, streak: cur, bestStreak: best },
    topics, weak, grid, recent, month: today.toLocaleString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' }),
  });
}));

module.exports = router;
