const express = require('express');
const db = require('../db');
const { wrap, iso, requireAuth, requireAdmin } = require('../lib');

const router = express.Router();
router.use(requireAuth, requireAdmin);

const TOPICS = ['Arrays', 'Strings', 'Trees', 'DP', 'Graphs', 'SQL', 'Sorting'];

router.get('/stats', wrap((req, res) => {
  const c = (sql) => db.prepare(sql).get().c;
  const scores = [
    ...db.prepare('SELECT avg_score s FROM interview_sessions WHERE avg_score IS NOT NULL').all().map((r) => r.s),
    ...db.prepare("SELECT correct*100.0/total s FROM quiz_attempts WHERE status='finished' AND total>0").all().map((r) => r.s),
  ];
  res.json({
    users: c('SELECT COUNT(*) c FROM users'),
    questions: c('SELECT COUNT(*) c FROM questions'),
    attemptsToday: c("SELECT COUNT(*) c FROM submissions WHERE date(created_at)=date('now')") + c("SELECT COUNT(*) c FROM quiz_attempts WHERE date(started_at)=date('now')") + c("SELECT COUNT(*) c FROM interview_sessions WHERE date(started_at)=date('now')"),
    avgScore: scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null,
  });
}));

router.get('/users', wrap((req, res) => {
  const search = `%${String(req.query.search || '').toLowerCase()}%`, plan = String(req.query.plan || 'all');
  const rows = db.prepare(`
    SELECT u.*,
      (SELECT COUNT(*) FROM user_questions x WHERE x.user_id=u.id AND x.solved=1) solved,
      (SELECT COUNT(*) FROM interview_sessions s WHERE s.user_id=u.id AND s.status='completed') interviews,
      (SELECT AVG(v) FROM (SELECT avg_score v FROM interview_sessions WHERE user_id=u.id AND avg_score IS NOT NULL
         UNION ALL SELECT correct*100.0/total FROM quiz_attempts WHERE user_id=u.id AND status='finished' AND total>0)) score
    FROM users u WHERE (lower(u.email) LIKE ? OR lower(u.first_name||' '||u.last_name) LIKE ?) ORDER BY u.id DESC LIMIT 200`).all(search, search);
  res.json({ users: rows.filter((u) => plan === 'all' || u.plan === plan).map((u) => ({
    id: u.id, name: `${u.first_name} ${u.last_name}`.trim(), email: u.email, plan: u.plan, role: u.role, banned: !!u.banned,
    avatar: ((u.first_name[0] || '') + (u.last_name[0] || u.first_name[1] || '')).toUpperCase(),
    solved: u.solved, interviews: u.interviews, score: u.score == null ? null : Math.round(u.score), lastActive: iso(u.last_active),
  })) });
}));

router.post('/users/:id/ban', wrap((req, res) => {
  const id = Number(req.params.id);
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  if (u.role === 'admin') return res.status(400).json({ error: 'Admins cannot be suspended' });
  db.prepare('UPDATE users SET banned = 1 - banned WHERE id=?').run(id);
  res.json({ banned: !u.banned });
}));

// ---- Questions ----
router.get('/questions', wrap((req, res) => {
  const search = `%${String(req.query.search || '').toLowerCase()}%`;
  const rows = db.prepare(`
    SELECT q.id, q.title, q.topic, q.diff,
      (SELECT COUNT(*) FROM submissions s WHERE s.question_id=q.id) attempts,
      (SELECT ROUND(AVG(passed*100.0/total)) FROM submissions s WHERE s.question_id=q.id) avgScore
    FROM questions q WHERE lower(q.title) LIKE ? OR lower(q.topic) LIKE ? ORDER BY q.id`).all(search, search);
  res.json({ questions: rows, topics: TOPICS });
}));

router.get('/questions/:id', wrap((req, res) => {
  const q = db.prepare('SELECT * FROM questions WHERE id=?').get(Number(req.params.id));
  if (!q) return res.status(404).json({ error: 'Not found' });
  const spec = q.tests ? JSON.parse(q.tests) : null;
  res.json({ id: q.id, title: q.title, diff: q.diff, topic: q.topic, tags: q.tags, description: q.description, kind: q.kind,
    fnName: q.fn_name || '', starter: q.starter_js || '', sqlSetup: q.sql_setup || '', tests: spec ? JSON.stringify(spec.cases, null, 1) : '' });
}));

function parseQuestion(body) {
  const q = {
    title: String(body.title || '').trim().slice(0, 200), diff: String(body.diff || ''), topic: String(body.topic || '').trim().slice(0, 40),
    tags: String(body.tags || '').trim().slice(0, 200), description: String(body.description || '').trim().slice(0, 6000),
    kind: body.kind === 'sql' ? 'sql' : 'code', fn: String(body.fnName || '').trim(), params: String(body.params || '').trim(),
    starter: String(body.starter || ''), sqlSetup: String(body.sqlSetup || ''), testsRaw: String(body.tests || '').trim(),
  };
  if (!q.title) return { error: 'Title is required' };
  if (!['Easy', 'Medium', 'Hard'].includes(q.diff)) return { error: 'Invalid difficulty' };
  if (!q.topic) return { error: 'Topic is required' };
  if (!q.description) return { error: 'Description is required' };
  let cases = null;
  if (q.testsRaw) {
    try { cases = JSON.parse(q.testsRaw); } catch { return { error: 'Test cases must be valid JSON' }; }
    if (!Array.isArray(cases) || !cases.length) return { error: 'Test cases must be a non-empty JSON array' };
    if (q.kind === 'code' && !cases.every((c) => Array.isArray(c.args) && 'expected' in c)) return { error: 'Each code test needs {"args": [...], "expected": ...}' };
    if (q.kind === 'sql' && !(Array.isArray(cases[0]?.expected))) return { error: 'SQL test needs [{"expected": [[row values...], ...]}]' };
  }
  if (q.kind === 'code' && cases && !/^[A-Za-z_$][\w$]*$/.test(q.fn)) return { error: 'A valid function name is required when test cases are provided' };
  if (q.kind === 'sql' && cases && !q.sqlSetup.trim()) return { error: 'SQL setup (CREATE TABLE / INSERT) is required for SQL questions with tests' };
  if (!q.starter) q.starter = q.kind === 'sql' ? '-- Write your SQL query here\nSELECT ' : q.fn ? `function ${q.fn}(${q.params}) {\n  // Write your solution here\n}\n` : '// Write your solution here\n';
  return { q, tests: cases ? JSON.stringify({ mode: 'call', cases }) : null };
}

router.post('/questions', wrap((req, res) => {
  const p = parseQuestion(req.body); if (p.error) return res.status(400).json({ error: p.error });
  const { q } = p;
  const info = db.prepare('INSERT INTO questions (title,diff,topic,tags,description,kind,fn_name,starter_js,tests,sql_setup) VALUES (?,?,?,?,?,?,?,?,?,?)')
    .run(q.title, q.diff, q.topic, q.tags, q.description, q.kind, q.fn || null, q.starter, p.tests, q.sqlSetup || null);
  res.status(201).json({ id: info.lastInsertRowid });
}));

router.put('/questions/:id', wrap((req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare('SELECT 1 FROM questions WHERE id=?').get(id)) return res.status(404).json({ error: 'Not found' });
  const p = parseQuestion(req.body); if (p.error) return res.status(400).json({ error: p.error });
  const { q } = p;
  db.prepare('UPDATE questions SET title=?,diff=?,topic=?,tags=?,description=?,kind=?,fn_name=?,starter_js=?,tests=?,sql_setup=? WHERE id=?')
    .run(q.title, q.diff, q.topic, q.tags, q.description, q.kind, q.fn || null, q.starter, p.tests, q.sqlSetup || null, id);
  res.json({ ok: true });
}));

router.delete('/questions/:id', wrap((req, res) => {
  const r = db.prepare('DELETE FROM questions WHERE id=?').run(Number(req.params.id));
  if (!r.changes) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true });
}));

// ---- Analytics ----
router.get('/analytics', wrap((req, res) => {
  const top = db.prepare(`SELECT q.title label, COUNT(*) val FROM submissions s JOIN questions q ON q.id=s.question_id GROUP BY q.id ORDER BY val DESC LIMIT 5`).all();
  const topics = db.prepare(`SELECT q.topic label, ROUND(AVG(s.passed*100.0/s.total)) val FROM submissions s JOIN questions q ON q.id=s.question_id GROUP BY q.topic ORDER BY val DESC LIMIT 6`).all();
  const byDay = Object.fromEntries(db.prepare(`
    SELECT d, SUM(n) n FROM (
      SELECT date(created_at) d, COUNT(*) n FROM submissions WHERE created_at >= date('now','-6 days') GROUP BY d
      UNION ALL SELECT date(started_at), COUNT(*) FROM quiz_attempts WHERE started_at >= date('now','-6 days') GROUP BY 1
      UNION ALL SELECT date(started_at), COUNT(*) FROM interview_sessions WHERE started_at >= date('now','-6 days') GROUP BY 1
    ) GROUP BY d`).all().map((r) => [r.d, r.n]));
  const weekly = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setUTCDate(d.getUTCDate() - i);
    const k = d.toISOString().slice(0, 10);
    weekly.push({ label: d.toLocaleString('en-US', { weekday: 'short', timeZone: 'UTC' }), val: byDay[k] || 0 });
  }
  res.json({ top, topics, weekly });
}));

module.exports = router;
