const express = require('express');
const db = require('../db');
const ai = require('../ai');
const { LIMITS, wrap, iso, requireAuth, requirePro, logActivity } = require('../lib');

const router = express.Router();
router.use(requireAuth);

const TOPICS = ['React Hooks', 'DBMS Normalization', 'OS Scheduling', 'System Design Basics', 'JavaScript Promises', 'Data Structures', 'Graph Algorithms', 'SQL Queries'];
const monthlyCount = (uid) => db.prepare("SELECT COUNT(*) c FROM quiz_attempts WHERE user_id=? AND started_at >= date('now','start of month')").get(uid).c;

function shuffle(a) {
  a = [...a];
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

router.get('/topics', (req, res) => {
  const counts = Object.fromEntries(db.prepare('SELECT topic, COUNT(*) c FROM quiz_bank GROUP BY topic').all().map((r) => [r.topic, r.c]));
  res.json({ topics: TOPICS.map((t) => ({ name: t, questions: counts[t] || 0 })), aiEnabled: ai.aiEnabled(), used: monthlyCount(req.user.id), limit: req.pro ? null : LIMITS.freeQuizzesPerMonth });
});

router.post('/start', wrap(async (req, res) => {
  const topic = String(req.body.topic || ''), count = parseInt(req.body.count, 10), timeMin = parseInt(req.body.timeMin, 10);
  if (!TOPICS.includes(topic)) return res.status(400).json({ error: 'Unknown topic' });
  if (![5, 10, 15, 20].includes(count)) return res.status(400).json({ error: 'Invalid question count' });
  if (![5, 10, 20, 30].includes(timeMin)) return res.status(400).json({ error: 'Invalid time limit' });
  if (!req.pro && monthlyCount(req.user.id) >= LIMITS.freeQuizzesPerMonth)
    return res.status(402).json({ error: `Free plan limit reached (${LIMITS.freeQuizzesPerMonth} quizzes / month). Upgrade to Pro for unlimited tests.`, upgrade: true });

  let have = db.prepare('SELECT COUNT(*) c FROM quiz_bank WHERE topic=?').get(topic).c;
  if (have < count && ai.aiEnabled()) {
    const gen = await ai.generateQuizQuestions(topic, count - have + 2);
    const ins = db.prepare("INSERT INTO quiz_bank (topic,question,options,answer,explanation,source) VALUES (?,?,?,?,?,'ai')");
    db.transaction(() => gen.forEach((g) => ins.run(topic, g.question, JSON.stringify(g.options), g.answer, String(g.explanation || ''))))();
    have += gen.length;
  }
  const rows = db.prepare('SELECT * FROM quiz_bank WHERE topic=? ORDER BY RANDOM() LIMIT ?').all(topic, count);
  if (!rows.length) return res.status(404).json({ error: 'No questions available for this topic yet.' });

  const picked = rows.map((r) => ({ id: r.id, perm: shuffle([0, 1, 2, 3]) }));
  const id = db.prepare('INSERT INTO quiz_attempts (user_id,topic,time_limit_sec,question_ids,total) VALUES (?,?,?,?,?)')
    .run(req.user.id, topic, timeMin * 60, JSON.stringify(picked), rows.length).lastInsertRowid;
  const questions = rows.map((r, i) => {
    const opts = JSON.parse(r.options);
    return { id: r.id, question: r.question, options: picked[i].perm.map((p) => opts[p]) };
  });
  res.json({
    attemptId: id, topic, total: rows.length, timeLimitSec: timeMin * 60, questions,
    note: rows.length < count ? `Only ${rows.length} questions are available for this topic right now.` : null,
  });
}));

function ownAttempt(req, res) {
  const a = db.prepare('SELECT * FROM quiz_attempts WHERE id=? AND user_id=?').get(Number(req.params.id), req.user.id);
  if (!a) { res.status(404).json({ error: 'Quiz not found' }); return null; }
  return a;
}
const elapsed = (a) => Math.round((Date.now() - new Date(iso(a.started_at)).getTime()) / 1000);

router.post('/:id/answer', wrap((req, res) => {
  const a = ownAttempt(req, res); if (!a) return;
  if (a.status !== 'active') return res.status(409).json({ error: 'Quiz already finished' });
  if (elapsed(a) > a.time_limit_sec + 5) return res.status(409).json({ error: 'Time is up' });
  const qIndex = parseInt(req.body.qIndex, 10), selected = parseInt(req.body.selected, 10);
  const picked = JSON.parse(a.question_ids);
  if (!(qIndex >= 0 && qIndex < picked.length) || !(selected >= 0 && selected < 4)) return res.status(400).json({ error: 'Invalid answer' });
  const q = db.prepare('SELECT answer, explanation FROM quiz_bank WHERE id=?').get(picked[qIndex].id);
  const perm = picked[qIndex].perm;
  const correctIndex = perm.indexOf(q.answer);
  const answers = JSON.parse(a.answers);
  if (answers[qIndex] === undefined) {       // first answer is final
    answers[qIndex] = selected;
    db.prepare('UPDATE quiz_attempts SET answers=? WHERE id=?').run(JSON.stringify(answers), a.id);
  }
  res.json({ selected: answers[qIndex], correctIndex, correct: answers[qIndex] === correctIndex, explanation: q.explanation });
}));

router.post('/:id/finish', wrap(async (req, res) => {
  const a = ownAttempt(req, res); if (!a) return;
  const picked = JSON.parse(a.question_ids), answers = JSON.parse(a.answers);
  if (a.status === 'active') {
    let correct = 0; const missed = [];
    picked.forEach((p, i) => {
      const q = db.prepare('SELECT question, answer, explanation FROM quiz_bank WHERE id=?').get(p.id);
      if (answers[i] !== undefined && p.perm.indexOf(q.answer) === answers[i]) correct++;
      else missed.push({ question: q.question, explanation: q.explanation });
    });
    const used = Math.min(elapsed(a), a.time_limit_sec);
    db.prepare("UPDATE quiz_attempts SET status='finished', correct=?, time_used_sec=?, finished_at=datetime('now') WHERE id=?").run(correct, used, a.id);
    logActivity(req.user.id, 'quiz', `${a.topic} Quiz`, `${correct}/${picked.length}`);
    a.correct = correct; a.time_used_sec = used; a._missed = missed;
  }
  const total = picked.length;
  const pct = Math.round((a.correct / total) * 100);
  const missed = a._missed || [];
  const feedback = await ai.quizFeedback({ topic: a.topic, correct: a.correct, total, missed });
  const others = db.prepare("SELECT correct*100.0/total AS pct FROM quiz_attempts WHERE topic=? AND status='finished' AND id != ? AND total > 0").all(a.topic, a.id);
  const percentile = others.length >= 5 ? Math.round((others.filter((o) => o.pct < pct).length / others.length) * 100) : null;
  res.json({ correct: a.correct, wrong: total - a.correct, total, pct, timeUsedSec: a.time_used_sec, feedback, percentile });
}));

router.get('/leaderboard', requirePro, wrap((req, res) => {
  const topic = String(req.query.topic || TOPICS[0]);
  const rows = db.prepare(`
    SELECT u.id, u.first_name, u.last_name, MAX(CAST(a.correct AS REAL)*100/a.total) AS best, MIN(a.time_used_sec) AS t
    FROM quiz_attempts a JOIN users u ON u.id = a.user_id
    WHERE a.topic=? AND a.status='finished' AND a.total > 0 AND u.banned = 0
    GROUP BY u.id ORDER BY best DESC, t ASC LIMIT 10`).all(topic);
  res.json({ topic, entries: rows.map((r) => ({
    userId: r.id, me: r.id === req.user.id,
    name: `${r.first_name}${r.last_name ? ' ' + r.last_name[0] + '.' : ''}`,
    avatar: ((r.first_name[0] || '') + (r.last_name[0] || r.first_name[1] || '')).toUpperCase(),
    score: Math.round(r.best),
  })) });
}));

module.exports = router;
