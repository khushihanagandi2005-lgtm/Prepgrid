const express = require('express');
const db = require('../db');
const ai = require('../ai');
const { interviewBank } = require('../seed');
const { LIMITS, wrap, iso, requireAuth, requirePro, logActivity } = require('../lib');

const router = express.Router();
router.use(requireAuth);

const TOTAL_Q = 8;
const DIFFS = ['Easy (Intern)', 'Medium (SDE-1)', 'Hard (SDE-2)'];

const monthlyCount = (uid) => db.prepare("SELECT COUNT(*) c FROM interview_sessions WHERE user_id=? AND started_at >= date('now','start of month')").get(uid).c;

router.get('/usage', (req, res) => {
  res.json({ used: monthlyCount(req.user.id), limit: req.pro ? null : LIMITS.freeInterviewsPerMonth, pro: req.pro, aiEnabled: ai.aiEnabled() });
});

function ownSession(req, res) {
  const s = db.prepare('SELECT * FROM interview_sessions WHERE id=? AND user_id=?').get(Number(req.params.id), req.user.id);
  if (!s) { res.status(404).json({ error: 'Session not found' }); return null; }
  return s;
}

function finalize(s, status) {
  const scored = db.prepare('SELECT score FROM interview_turns WHERE session_id=? AND score IS NOT NULL').all(s.id);
  const avg = scored.length ? Math.round(scored.reduce((a, t) => a + t.score, 0) / scored.length) : null;
  db.prepare("UPDATE interview_sessions SET status=?, ended_at=datetime('now'), avg_score=? WHERE id=? AND status='active'").run(status, avg, s.id);
  logActivity(s.user_id, 'interview', `AI Interview: ${s.role}`, avg == null ? 'Ended' : `Score ${avg}%`);
  return { avgScore: avg, answered: scored.length };
}

const remaining = (s) => Math.max(0, Math.round(s.duration_min * 60 - (Date.now() - new Date(iso(s.started_at)).getTime()) / 1000));

router.post('/start', wrap(async (req, res) => {
  const role = String(req.body.role || ''), difficulty = String(req.body.difficulty || ''), focus = String(req.body.focus || '').slice(0, 200);
  const dur = parseInt(req.body.duration, 10);
  if (!interviewBank[role]) return res.status(400).json({ error: 'Unknown interview role' });
  if (!DIFFS.includes(difficulty)) return res.status(400).json({ error: 'Unknown difficulty' });
  if (![15, 30, 45].includes(dur)) return res.status(400).json({ error: 'Duration must be 15, 30 or 45 minutes' });
  if (!req.pro && monthlyCount(req.user.id) >= LIMITS.freeInterviewsPerMonth)
    return res.status(402).json({ error: `Free plan limit reached (${LIMITS.freeInterviewsPerMonth} interviews / month). Upgrade to Pro for unlimited sessions.`, upgrade: true });

  db.prepare("UPDATE interview_sessions SET status='ended', ended_at=datetime('now') WHERE user_id=? AND status='active'").run(req.user.id);
  const id = db.prepare('INSERT INTO interview_sessions (user_id,role,difficulty,duration_min,focus,total_questions) VALUES (?,?,?,?,?,?)')
    .run(req.user.id, role, difficulty, dur, focus, TOTAL_Q).lastInsertRowid;
  const q = await ai.nextQuestion({ role, difficulty, focus, turns: [], idx: 0 });
  db.prepare('INSERT INTO interview_turns (session_id,idx,question) VALUES (?,?,?)').run(id, 0, q.text);
  res.json({ sessionId: id, role, total: TOTAL_Q, index: 0, question: q.text, durationSec: dur * 60, aiEnabled: ai.aiEnabled() });
}));

async function advance(s, res, extra) {
  const turns = db.prepare('SELECT idx, question, score FROM interview_turns WHERE session_id=? ORDER BY idx').all(s.id);
  const nextIdx = turns.length;
  if (nextIdx >= s.total_questions) {
    const sum = finalize(s, 'completed');
    return res.json({ ...extra, done: true, summary: sum });
  }
  const q = await ai.nextQuestion({ role: s.role, difficulty: s.difficulty, focus: s.focus, turns, idx: nextIdx });
  db.prepare('INSERT INTO interview_turns (session_id,idx,question) VALUES (?,?,?)').run(s.id, nextIdx, q.text);
  res.json({ ...extra, done: false, next: { index: nextIdx, question: q.text }, remainingSec: remaining(s) });
}

function currentTurn(s) {
  return db.prepare('SELECT * FROM interview_turns WHERE session_id=? AND answer IS NULL AND skipped=0 ORDER BY idx LIMIT 1').get(s.id);
}

router.post('/:id/answer', wrap(async (req, res) => {
  const s = ownSession(req, res); if (!s) return;
  if (s.status !== 'active') return res.status(409).json({ error: 'This session has already ended' });
  if (remaining(s) <= 0) { const sum = finalize(s, 'completed'); return res.status(409).json({ error: 'Time is up', done: true, summary: sum }); }
  const answer = String(req.body.answer || '').trim();
  if (!answer) return res.status(400).json({ error: 'Please write an answer first' });
  if (answer.length > 4000) return res.status(400).json({ error: 'Answer too long (max 4000 characters)' });
  const t = currentTurn(s);
  if (!t) return res.status(409).json({ error: 'No open question' });
  const ev = await ai.evaluateAnswer({ role: s.role, difficulty: s.difficulty, question: t.question, answer });
  db.prepare('UPDATE interview_turns SET answer=?, score=?, feedback=? WHERE id=?').run(answer, ev.score, ev.feedback, t.id);
  await advance(s, res, { score: ev.score, feedback: ev.feedback, scoredBy: ev.source });
}));

router.post('/:id/skip', wrap(async (req, res) => {
  const s = ownSession(req, res); if (!s) return;
  if (s.status !== 'active') return res.status(409).json({ error: 'This session has already ended' });
  const t = currentTurn(s);
  if (!t) return res.status(409).json({ error: 'No open question' });
  db.prepare('UPDATE interview_turns SET skipped=1 WHERE id=?').run(t.id);
  await advance(s, res, { skipped: true });
}));

router.post('/:id/end', wrap((req, res) => {
  const s = ownSession(req, res); if (!s) return;
  if (s.status !== 'active') return res.json({ summary: { avgScore: s.avg_score } });
  res.json({ summary: finalize(s, 'ended') });
}));

// ---- History (Pro) ----
router.get('/history', requirePro, wrap((req, res) => {
  const rows = db.prepare(`SELECT s.*, (SELECT COUNT(*) FROM interview_turns t WHERE t.session_id=s.id AND t.score IS NOT NULL) answered
    FROM interview_sessions s WHERE user_id=? AND status != 'active' ORDER BY id DESC LIMIT 50`).all(req.user.id);
  res.json({ sessions: rows.map((r) => ({
    id: r.id, role: r.role, difficulty: r.difficulty, date: iso(r.started_at), score: r.avg_score, answered: r.answered,
    minutes: r.ended_at ? Math.max(1, Math.round((new Date(iso(r.ended_at)) - new Date(iso(r.started_at))) / 60000)) : null,
  })) });
}));

router.get('/:id/review', requirePro, wrap((req, res) => {
  const s = ownSession(req, res); if (!s) return;
  const turns = db.prepare('SELECT idx, question, answer, score, feedback, skipped FROM interview_turns WHERE session_id=? ORDER BY idx').all(s.id);
  res.json({ session: { id: s.id, role: s.role, difficulty: s.difficulty, score: s.avg_score, date: iso(s.started_at) }, turns });
}));

module.exports = router;
