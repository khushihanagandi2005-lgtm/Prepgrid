const path = require('path');
const fs = require('fs');
const Database = require('./sqlite');

const dbPath = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'prepgrid.db');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',         -- user | admin
  plan TEXT NOT NULL DEFAULT 'Free',         -- Free | Pro
  plan_expires TEXT,
  banned INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_active TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reset_otps (
  email TEXT PRIMARY KEY COLLATE NOCASE,
  otp_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS questions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  diff TEXT NOT NULL CHECK (diff IN ('Easy','Medium','Hard')),
  topic TEXT NOT NULL,
  tags TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'code',         -- code | sql
  fn_name TEXT,                              -- function the user must implement
  starter_js TEXT,
  tests TEXT,                                -- JSON array of test cases
  sql_setup TEXT,                            -- for kind=sql: schema + data
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS user_questions (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  question_id INTEGER NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  solved INTEGER NOT NULL DEFAULT 0,
  bookmarked INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, question_id)
);

CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  question_id INTEGER NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  lang TEXT NOT NULL,
  code TEXT NOT NULL,
  passed INTEGER NOT NULL,
  total INTEGER NOT NULL,
  runtime_ms INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sub_user ON submissions(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_sub_q ON submissions(question_id);

CREATE TABLE IF NOT EXISTS interview_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  difficulty TEXT NOT NULL,
  duration_min INTEGER NOT NULL,
  focus TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active',      -- active | completed | ended
  total_questions INTEGER NOT NULL DEFAULT 8,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  ended_at TEXT,
  avg_score INTEGER
);

CREATE TABLE IF NOT EXISTS interview_turns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES interview_sessions(id) ON DELETE CASCADE,
  idx INTEGER NOT NULL,
  question TEXT NOT NULL,
  answer TEXT,
  score INTEGER,
  feedback TEXT,
  skipped INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS quiz_bank (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  topic TEXT NOT NULL,
  question TEXT NOT NULL,
  options TEXT NOT NULL,                      -- JSON array of 4
  answer INTEGER NOT NULL,
  explanation TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'seed'         -- seed | ai | admin
);
CREATE INDEX IF NOT EXISTS idx_quiz_topic ON quiz_bank(topic);

CREATE TABLE IF NOT EXISTS quiz_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  topic TEXT NOT NULL,
  time_limit_sec INTEGER NOT NULL,
  question_ids TEXT NOT NULL,                 -- JSON array of quiz_bank ids (ordered)
  answers TEXT NOT NULL DEFAULT '{}',         -- JSON {questionId: selectedIndex}
  status TEXT NOT NULL DEFAULT 'active',      -- active | finished
  correct INTEGER,
  total INTEGER,
  time_used_sec INTEGER,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT
);

CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,                     -- razorpay | sandbox
  order_id TEXT NOT NULL UNIQUE,
  payment_id TEXT,
  amount_paise INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'created',     -- created | paid | failed
  description TEXT NOT NULL DEFAULT 'PrepGrid Pro - 1 month',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS activity_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,                         -- solved | attempted | interview | quiz
  title TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_act_user ON activity_log(user_id, created_at);
`);

module.exports = db;
