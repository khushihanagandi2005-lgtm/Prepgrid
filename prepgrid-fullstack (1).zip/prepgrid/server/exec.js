const { spawn, spawnSync } = require('child_process');
const path = require('path');
const Database = require('./sqlite');

const RUNNER = path.join(__dirname, 'sandbox', 'runner.js');

// Use Node's permission model (no fs write / child_process / worker access) when this Node version supports it.
function childEnv() {
  // Windows needs SystemRoot to start Node; everything else (secrets, keys) stays hidden from the sandbox
  return process.platform === 'win32' && process.env.SystemRoot ? { SystemRoot: process.env.SystemRoot } : {};
}
function detectPermissionFlag() {
  for (const flag of ['--permission', '--experimental-permission']) {
    const r = spawnSync(process.execPath, [flag, `--allow-fs-read=${RUNNER}`, RUNNER], { env: childEnv(), input: 'x', timeout: 8000, encoding: 'utf8' });
    if (r.status === 0 && /Bad job/.test(r.stdout || '')) return flag;
  }
  return null;
}
const PERM_FLAG = detectPermissionFlag();
if (!PERM_FLAG) console.warn('[exec] Node permission model unavailable; code runs in vm + isolated process only.');

function runJS({ code, fn, mode, cases }) {
  return new Promise((resolve) => {
    const args = ['--max-old-space-size=96', RUNNER];
    if (PERM_FLAG) args.unshift(PERM_FLAG, `--allow-fs-read=${RUNNER}`);
    // minimal env so the sandbox can never see JWT_SECRET, API keys, etc.
    const child = spawn(process.execPath, args, { env: childEnv(), stdio: ['pipe', 'pipe', 'pipe'] });
    let stdout = '', killed = false;
    const timer = setTimeout(() => { killed = true; child.kill('SIGKILL'); }, 10000);
    child.stdout.on('data', (d) => { if (stdout.length < 1e6) stdout += d; });
    child.stderr.on('data', () => {});
    child.on('close', () => {
      clearTimeout(timer);
      if (killed) return resolve({ ok: false, error: 'Time Limit Exceeded' });
      try { resolve(JSON.parse(stdout)); } catch { resolve({ ok: false, error: 'Execution failed (out of memory or crashed)' }); }
    });
    child.stdin.on('error', () => {});
    child.stdin.end(JSON.stringify({ code, fn, mode, cases }));
  });
}

function runSQL(userSql, setup, expected) {
  const clean = String(userSql || '').replace(/--.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').trim().replace(/;+\s*$/, '');
  if (!/^(select|with)\b/i.test(clean) || clean.includes(';')) return { ok: false, error: 'Only a single SELECT query is allowed.' };
  const mem = new Database(':memory:');
  try {
    mem.exec(setup);
    const t0 = process.hrtime.bigint();
    const stmt = mem.prepare(clean);          // throws on multiple statements / syntax errors
    if (!stmt.reader) return { ok: false, error: 'Query must return rows.' };
    const rows = stmt.raw(true).all().slice(0, 500);
    const ms = Number(process.hrtime.bigint() - t0) / 1e6;
    const key = (r) => JSON.stringify(r);
    const a = rows.map(key).sort(), b = expected.map(key).sort();
    return { ok: true, passed: JSON.stringify(a) === JSON.stringify(b), rows, expected, ms };
  } catch (e) {
    return { ok: false, error: String(e.message).slice(0, 300) };
  } finally { mem.close(); }
}

module.exports = { runJS, runSQL };
