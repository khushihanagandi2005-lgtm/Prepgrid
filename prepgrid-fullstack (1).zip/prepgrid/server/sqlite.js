// Thin wrapper over Node's built-in node:sqlite (no native compilation needed) that
// exposes the small better-sqlite3-style API the rest of the app uses.
const { DatabaseSync } = require('node:sqlite');

class Statement {
  constructor(st) { this.st = st; this._raw = false; }
  get reader() { return this.st.columns().length > 0; }
  raw(on = true) {
    this._raw = !!on;
    if (typeof this.st.setReturnArrays === 'function') this.st.setReturnArrays(this._raw);
    return this;
  }
  _arr(rows) { return this._raw && typeof this.st.setReturnArrays !== 'function' ? rows.map((r) => Object.values(r)) : rows; }
  get(...p) { const r = this.st.get(...p); return r === undefined ? undefined : this._arr([r])[0]; }
  all(...p) { return this._arr(this.st.all(...p)); }
  run(...p) { return this.st.run(...p); }
}

class Database {
  constructor(path) { this.d = new DatabaseSync(path); }
  exec(sql) { this.d.exec(sql); return this; }
  pragma(s) { this.d.exec('PRAGMA ' + s); }
  prepare(sql) { return new Statement(this.d.prepare(sql)); }
  transaction(fn) {
    return (...args) => {
      this.d.exec('BEGIN');
      try { const r = fn(...args); this.d.exec('COMMIT'); return r; }
      catch (e) { try { this.d.exec('ROLLBACK'); } catch { /* already rolled back */ } throw e; }
    };
  }
  close() { this.d.close(); }
}

module.exports = Database;
