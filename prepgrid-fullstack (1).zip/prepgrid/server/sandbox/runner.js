// Executed as an isolated child process by server/exec.js. Reads a JSON job on stdin, writes JSON result to stdout.
const vm = require('vm');

const HELPERS = `
(function () {
  class ListNode { constructor(val, next) { this.val = val === undefined ? 0 : val; this.next = next === undefined ? null : next; } }
  class TreeNode { constructor(val, left, right) { this.val = val === undefined ? 0 : val; this.left = left === undefined ? null : left; this.right = right === undefined ? null : right; } }
  const g = globalThis;
  g.ListNode = ListNode; g.TreeNode = TreeNode;
  g.__buildList = (a) => { let h = null; for (let i = a.length - 1; i >= 0; i--) h = new ListNode(a[i], h); return h; };
  g.__listToArray = (h) => { const o = []; let n = 0; while (h && n++ < 100000) { o.push(h.val); h = h.next; } return o; };
  g.__buildTree = (a) => {
    if (!a.length || a[0] === null) return null;
    const root = new TreeNode(a[0]); const q = [root]; let i = 1;
    while (q.length && i < a.length) {
      const n = q.shift();
      if (i < a.length && a[i] !== null) { n.left = new TreeNode(a[i]); q.push(n.left); } i++;
      if (i < a.length && a[i] !== null) { n.right = new TreeNode(a[i]); q.push(n.right); } i++;
    }
    return root;
  };
  g.__treeToArray = (root) => {
    if (!root) return [];
    const out = []; const q = [root];
    while (q.length) { const n = q.shift(); if (n) { out.push(n.val); q.push(n.left, n.right); } else out.push(null); }
    while (out.length && out[out.length - 1] === null) out.pop();
    return out;
  };
  const logs = []; g.__logs = logs;
  const log = (...a) => { if (logs.length < 30) logs.push(a.map(x => { try { return typeof x === 'string' ? x : JSON.stringify(x); } catch (e) { return String(x); } }).join(' ').slice(0, 300)); };
  g.console = { log, error: log, warn: log, info: log };
})();
`;

function norm(v, unordered) {
  if (unordered && Array.isArray(v)) return JSON.stringify([...v].sort((a, b) => a - b));
  return JSON.stringify(v);
}

let input = '';
process.stdin.on('data', d => (input += d));
process.stdin.on('end', () => {
  let job;
  try { job = JSON.parse(input); } catch { return out({ ok: false, error: 'Bad job' }); }
  const { code, fn, mode, cases } = job;
  // Null-prototype sandbox: a plain {} would leak the host realm's Object/Function via this.constructor.constructor
  const ctx = vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } });

  try {
    vm.runInContext(HELPERS, ctx, { timeout: 1000 });
    vm.runInContext(String(code), ctx, { timeout: 2000, filename: 'solution.js' });
  } catch (e) {
    return out({ ok: false, error: String(e && e.message ? e.message : e).slice(0, 400), logs: readLogs(ctx) });
  }

  const results = [];
  for (const c of cases) {
    const r = { hidden: !!c.hidden, passed: false };
    const t0 = process.hrtime.bigint();
    try {
      ctx.__specStr = JSON.stringify(c);
      let script;
      if (mode === 'roundtrip') {
        script = `(function(){ const s = JSON.parse(__specStr); const t = __buildTree(s.args[0]);
          const enc = serialize(t); if (typeof enc !== 'string') throw new Error('serialize() must return a string');
          return JSON.stringify([__treeToArray(deserialize(enc)), __treeToArray(__buildTree(s.args[0]))]); })()`;
      } else {
        script = `(function(){ const s = JSON.parse(__specStr);
          const args = s.args.map((a, i) => { const t = (s.argTypes || [])[i]; return t === 'list' ? __buildList(a) : t === 'tree' ? __buildTree(a) : a; });
          if (typeof ${fn} !== 'function') throw new Error('Function ${fn} is not defined');
          let r = ${fn}.apply(null, args);
          if (s.retType === 'list') r = __listToArray(r);
          return JSON.stringify(r === undefined ? null : r); })()`;
      }
      const raw = vm.runInContext(script, ctx, { timeout: 2000 });
      const parsed = JSON.parse(raw);
      if (mode === 'roundtrip') { r.got = parsed[0]; r.expected = parsed[1]; }
      else { r.got = parsed; r.expected = c.expected; }
      r.passed = norm(r.got, c.unordered) === norm(r.expected, c.unordered);
    } catch (e) {
      const msg = String(e && e.message ? e.message : e);
      r.error = /timed out/i.test(msg) ? 'Time Limit Exceeded (2s)' : msg.slice(0, 300);
    }
    r.ms = Number(process.hrtime.bigint() - t0) / 1e6;
    r.input = c.args;
    results.push(r);
  }
  out({ ok: true, results, logs: readLogs(ctx) });
});

function readLogs(ctx) { try { return JSON.parse(vm.runInContext('JSON.stringify(__logs)', ctx)); } catch { return []; } }
function out(o) { process.stdout.write(JSON.stringify(o)); }
