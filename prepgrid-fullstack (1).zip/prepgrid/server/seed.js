const bcrypt = require('bcryptjs');
const db = require('./db');

// ---------- Interview question bank (used when no AI key is configured, and as AI fallback) ----------
const interviewBank = {
  'Frontend Engineer': ['Explain the difference between controlled and uncontrolled components in React.', 'What is the virtual DOM and how does React use it?', "Explain event delegation and why it's useful.", 'What are CSS specificity rules and how are conflicts resolved?', 'How does the JavaScript event loop work?', 'What is the difference between localStorage, sessionStorage, and cookies?', 'Explain the concept of closures with an example.', 'What are React hooks and why were they introduced?'],
  'Backend Engineer': ['Explain REST vs GraphQL and when to use each.', 'What is database indexing and when should you use it?', 'How does horizontal vs vertical scaling differ?', 'Explain ACID properties in databases.', 'What is the CAP theorem?', "Describe how you'd design a URL shortener.", 'What are the key differences between SQL and NoSQL databases?', 'Explain what a race condition is and how to prevent it.'],
  'Full Stack Developer': ['How would you handle authentication in a full stack app?', 'Explain the concept of SSR vs CSR and when to use each.', 'What is CORS and how do you handle it?', 'How do you handle environment variables securely?', 'Explain the difference between monolith and microservices.', 'What is WebSocket and when would you use it over REST?', 'How do you optimize database queries in a production app?', 'Describe your approach to debugging a performance issue.'],
  'DSA / Competitive': ['Explain dynamic programming with the knapsack problem.', "What is the time complexity of Dijkstra's algorithm?", 'How do you detect a cycle in a linked list?', 'Explain the concept of memoization vs tabulation.', 'What is a trie and what are its applications?', "Describe how QuickSort works and its average/worst case.", 'What is the two-pointer technique and when is it applicable?', 'Explain segment trees and their use cases.'],
  'System Design': ['Design a scalable notification system.', "How would you design Twitter's feed?", 'Explain how a distributed cache like Redis works.', 'Design a rate limiter for an API.', 'How would you design a file upload service?', 'Explain consistent hashing and its use in distributed systems.', 'How do you handle database sharding?', 'Design a real-time collaborative editing system.'],
};

// ---------- Coding questions ----------
// Test spec: {args, expected, argTypes?, retType?, unordered?, hidden?}  types: 'list' | 'tree'
const big = Array.from({ length: 2000 }, (_, i) => 2000 - i);
const bigSorted = [...big].sort((a, b) => a - b);

const Q = [
  { title: 'Two Sum', diff: 'Easy', topic: 'Arrays', tags: 'hash-map', fn: 'twoSum', params: 'nums, target',
    desc: 'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target. You may assume that each input would have exactly one solution, and you may not use the same element twice. Return the indices in any order.',
    tests: [{ args: [[2, 7, 11, 15], 9], expected: [0, 1], unordered: true }, { args: [[3, 2, 4], 6], expected: [1, 2], unordered: true }, { args: [[3, 3], 6], expected: [0, 1], unordered: true }, { args: [[-1, -2, -3, -4, -5], -8], expected: [2, 4], unordered: true, hidden: true }] },
  { title: 'Valid Parentheses', diff: 'Easy', topic: 'Strings', tags: 'stack', fn: 'isValid', params: 's',
    desc: "Given a string s containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid. Open brackets must be closed by the same type of brackets, in the correct order.",
    tests: [{ args: ['()'], expected: true }, { args: ['()[]{}'], expected: true }, { args: ['(]'], expected: false }, { args: ['([)]'], expected: false, hidden: true }, { args: ['{[]}'], expected: true, hidden: true }] },
  { title: 'Merge Two Sorted Lists', diff: 'Easy', topic: 'Trees', tags: 'linked-list', fn: 'mergeTwoLists', params: 'list1, list2',
    desc: 'You are given the heads of two sorted linked lists list1 and list2 (nodes are ListNode objects with val and next). Merge the two lists into one sorted list and return its head. A ListNode class is available in the sandbox.',
    tests: [{ args: [[1, 2, 4], [1, 3, 4]], argTypes: ['list', 'list'], retType: 'list', expected: [1, 1, 2, 3, 4, 4] }, { args: [[], []], argTypes: ['list', 'list'], retType: 'list', expected: [] }, { args: [[], [0]], argTypes: ['list', 'list'], retType: 'list', expected: [0] }, { args: [[5], [1, 2, 4]], argTypes: ['list', 'list'], retType: 'list', expected: [1, 2, 4, 5], hidden: true }] },
  { title: 'Binary Tree Level Order Traversal', diff: 'Medium', topic: 'Trees', tags: 'bfs,tree', fn: 'levelOrder', params: 'root',
    desc: "Given the root of a binary tree (TreeNode with val, left, right), return the level order traversal of its nodes' values (i.e., from left to right, level by level). A TreeNode class is available in the sandbox.",
    tests: [{ args: [[3, 9, 20, null, null, 15, 7]], argTypes: ['tree'], expected: [[3], [9, 20], [15, 7]] }, { args: [[1]], argTypes: ['tree'], expected: [[1]] }, { args: [[]], argTypes: ['tree'], expected: [] }, { args: [[1, 2, 3, 4, null, null, 5]], argTypes: ['tree'], expected: [[1], [2, 3], [4, 5]], hidden: true }] },
  { title: 'Longest Palindromic Substring', diff: 'Medium', topic: 'DP', tags: 'string,expand-around-center', fn: 'longestPalindrome', params: 's',
    desc: 'Given a string s, return the longest palindromic substring in s.',
    tests: [{ args: ['cbbd'], expected: 'bb' }, { args: ['a'], expected: 'a' }, { args: ['racecar'], expected: 'racecar' }, { args: ['forgeeksskeegfor'], expected: 'geeksskeeg', hidden: true }] },
  { title: 'Number of Islands', diff: 'Medium', topic: 'Graphs', tags: 'dfs,bfs,grid', fn: 'numIslands', params: 'grid',
    desc: "Given an m x n 2D binary grid grid (array of arrays of the strings '1' and '0') which represents a map of '1's (land) and '0's (water), return the number of islands.",
    tests: [{ args: [[['1', '1', '1', '1', '0'], ['1', '1', '0', '1', '0'], ['1', '1', '0', '0', '0'], ['0', '0', '0', '0', '0']]], expected: 1 }, { args: [[['1', '1', '0', '0', '0'], ['1', '1', '0', '0', '0'], ['0', '0', '1', '0', '0'], ['0', '0', '0', '1', '1']]], expected: 3 }, { args: [[['1', '0', '1'], ['0', '1', '0'], ['1', '0', '1']]], expected: 5, hidden: true }] },
  { title: 'Coin Change', diff: 'Medium', topic: 'DP', tags: 'dp', fn: 'coinChange', params: 'coins, amount',
    desc: 'You are given an integer array coins representing coins of various denominations and an integer amount representing a total amount of money. Return the fewest number of coins needed to make up that amount, or -1 if it cannot be made.',
    tests: [{ args: [[1, 2, 5], 11], expected: 3 }, { args: [[2], 3], expected: -1 }, { args: [[1], 0], expected: 0 }, { args: [[1, 3, 4], 6], expected: 2, hidden: true }] },
  { title: 'Word Break', diff: 'Medium', topic: 'DP', tags: 'dp,string', fn: 'wordBreak', params: 's, wordDict',
    desc: 'Given a string s and a dictionary of strings wordDict, return true if s can be segmented into a space-separated sequence of one or more dictionary words.',
    tests: [{ args: ['leetcode', ['leet', 'code']], expected: true }, { args: ['applepenapple', ['apple', 'pen']], expected: true }, { args: ['catsandog', ['cats', 'dog', 'sand', 'and', 'cat']], expected: false, hidden: true }] },
  { title: 'Graph Valid Tree', diff: 'Medium', topic: 'Graphs', tags: 'union-find,graph', fn: 'validTree', params: 'n, edges',
    desc: 'You have a graph of n nodes labeled from 0 to n-1. You are given an integer n and a list of edges where edges[i] = [ai, bi] indicates that there is an undirected edge between nodes ai and bi. Return true if the edges of the given graph make up a valid tree, and false otherwise.',
    tests: [{ args: [5, [[0, 1], [0, 2], [0, 3], [1, 4]]], expected: true }, { args: [5, [[0, 1], [1, 2], [2, 3], [1, 3], [1, 4]]], expected: false }, { args: [4, [[0, 1], [2, 3]]], expected: false, hidden: true }, { args: [1, []], expected: true, hidden: true }] },
  { title: 'Trapping Rain Water', diff: 'Hard', topic: 'Arrays', tags: 'two-pointer', fn: 'trap', params: 'height',
    desc: 'Given n non-negative integers representing an elevation map where the width of each bar is 1, compute how much water it can trap after raining.',
    tests: [{ args: [[0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1]], expected: 6 }, { args: [[4, 2, 0, 3, 2, 5]], expected: 9 }, { args: [[3, 0, 3]], expected: 3, hidden: true }] },
  { title: 'N-Queens', diff: 'Hard', topic: 'Arrays', tags: 'backtracking', fn: 'totalNQueens', params: 'n',
    desc: 'The n-queens puzzle is the problem of placing n queens on an n x n chessboard such that no two queens attack each other. Given an integer n, return the number of distinct solutions to the n-queens puzzle.',
    tests: [{ args: [4], expected: 2 }, { args: [1], expected: 1 }, { args: [6], expected: 4, hidden: true }, { args: [8], expected: 92, hidden: true }] },
  { title: 'Serialize and Deserialize Binary Tree', diff: 'Hard', topic: 'Trees', tags: 'tree,design', fn: 'serialize', params: 'root', mode: 'roundtrip',
    desc: 'Design an algorithm to serialize and deserialize a binary tree. Implement BOTH functions: serialize(root) must return a string, and deserialize(data) must rebuild the same tree (TreeNode objects). Tests check deserialize(serialize(tree)).',
    extraStarter: '\nfunction deserialize(data) {\n  // Rebuild the tree from the string\n}\n',
    tests: [{ args: [[1, 2, 3, null, null, 4, 5]], expected: null }, { args: [[]], expected: null }, { args: [[1]], expected: null, hidden: true }, { args: [[1, null, 2, 3]], expected: null, hidden: true }] },
  { title: 'Employee Salary Report', diff: 'Easy', topic: 'SQL', tags: 'subquery,join', kind: 'sql',
    desc: 'Table Employee(id, name, salary, department). Write a SQL query to find all employees who earn more than the average salary of their department. Return columns: name, salary, department (row order does not matter).',
    sql_setup: "CREATE TABLE Employee(id INTEGER, name TEXT, salary INTEGER, department TEXT); INSERT INTO Employee VALUES (1,'Asha',70000,'Eng'),(2,'Ben',50000,'Eng'),(3,'Chen',60000,'Eng'),(4,'Dia',40000,'HR'),(5,'Eli',45000,'HR'),(6,'Fay',90000,'Sales');",
    tests: [{ expected: [['Asha', 70000, 'Eng'], ['Eli', 45000, 'HR']] }] },
  { title: 'Second Highest Salary', diff: 'Medium', topic: 'SQL', tags: 'subquery,limit', kind: 'sql',
    desc: 'Table Employee(id, salary). Write a SQL query to report the second highest DISTINCT salary as a single column. (Duplicates of the top salary must not count as the second highest.)',
    sql_setup: 'CREATE TABLE Employee(id INTEGER, salary INTEGER); INSERT INTO Employee VALUES (1,100),(2,200),(3,300),(4,300);',
    tests: [{ expected: [[200]] }] },
  { title: 'Merge Sort Implementation', diff: 'Medium', topic: 'Sorting', tags: 'divide-and-conquer', fn: 'mergeSort', params: 'arr',
    desc: 'Implement merge sort: return a NEW array containing the elements of arr in ascending order. Handle edge cases (empty array, duplicates, negatives). Your solution must be O(n log n); the hidden tests include a 2000-element input.',
    tests: [{ args: [[5, 2, 4, 7, 1, 3, 2, 6]], expected: [1, 2, 2, 3, 4, 5, 6, 7] }, { args: [[]], expected: [] }, { args: [[1]], expected: [1] }, { args: [[3, -1, 0, -5, 10, 10]], expected: [-5, -1, 0, 3, 10, 10], hidden: true }, { args: [big], expected: bigSorted, hidden: true }] },
];

function starterFor(q) {
  if (q.kind === 'sql') return '-- Write your SQL query here\nSELECT ';
  const hints = [];
  if ((q.tests[0].argTypes || []).includes('list')) hints.push('// ListNode { val, next } is available');
  if ((q.tests[0].argTypes || []).includes('tree')) hints.push('// TreeNode { val, left, right } is available');
  return `${hints.length ? hints.join('\n') + '\n' : ''}function ${q.fn}(${q.params}) {\n  // Write your solution here\n}\n${q.extraStarter || ''}`;
}

// ---------- Quiz bank ----------
const quiz = {
  'React Hooks': [
    ['What is the primary purpose of the useCallback hook in React?', ['To memoize a function so it is not recreated on every render', 'To manage side effects in functional components', 'To access the previous state value', 'To create a ref for a DOM element'], 0, 'useCallback returns a memoized callback function that only changes if one of the dependencies has changed, preventing unnecessary re-renders of child components.'],
    ['Which hook would you use to perform data fetching in a React component?', ['useState', 'useRef', 'useEffect', 'useContext'], 2, 'useEffect is designed for side effects like data fetching, subscriptions, and manual DOM mutations.'],
    ['What does the dependency array in useEffect control?', ['The order of hook calls', 'When the effect runs by tracking changes to listed values', 'The maximum number of renders', 'The scope of state variables'], 1, 'The dependency array tells React to re-run the effect only when the listed values change. An empty array means run only once after mount.'],
    ['Which hook provides a way to share state across components without prop drilling?', ['useState', 'useReducer', 'useContext', 'useRef'], 2, 'useContext accepts a context object and returns the current context value, allowing you to share data deeply without prop drilling.'],
    ['What is the correct way to update state that depends on the previous state in React?', ['setState(state + 1)', 'setState(prev => prev + 1)', 'state = state + 1', 'useEffect(() => setState(state + 1))'], 1, 'When new state depends on previous state, always use the functional form of setState to avoid stale closures.'],
  ],
  'DBMS Normalization': [
    ['A relation is in 2NF if it is in 1NF and...', ['has no partial dependency of non-key attributes on part of a composite key', 'has no transitive dependencies', 'every determinant is a candidate key', 'has no multi-valued attributes'], 0, '2NF removes partial dependencies: every non-key attribute must depend on the whole candidate key.'],
    ['Which normal form removes transitive dependencies?', ['1NF', '2NF', '3NF', 'Both 1NF and 2NF'], 2, '3NF requires that non-key attributes depend only on the key, not on other non-key attributes.'],
    ['BCNF is stricter than 3NF because it requires that...', ['every determinant is a superkey', 'every attribute is atomic', 'no partial dependencies exist', 'all tables have a single-column primary key'], 0, 'In BCNF, for every non-trivial functional dependency X -> Y, X must be a superkey.'],
  ],
  'OS Scheduling': [
    ['Which scheduling algorithm can cause starvation of long processes?', ['Round Robin', 'FCFS', 'Shortest Job First', 'None of them'], 2, 'SJF keeps picking short jobs, so a long job may wait indefinitely if short jobs keep arriving.'],
    ['In Round Robin scheduling, what happens if the time quantum is extremely large?', ['It behaves like FCFS', 'It behaves like SJF', 'Context switches increase sharply', 'Starvation becomes certain'], 0, 'If the quantum exceeds every burst, each process finishes in its first turn, which is exactly FCFS.'],
    ["What is the 'convoy effect'?", ['Short processes wait behind a long CPU-bound process', 'Multiple processes share one page', 'Processes continually swap in and out', 'A low-priority process blocks a high-priority one'], 0, 'In FCFS, many short processes queue behind one long CPU-bound process, lowering utilization and increasing average wait time.'],
  ],
  'System Design Basics': [
    ['What is the main purpose of a load balancer?', ['Distribute incoming requests across multiple servers', 'Encrypt data at rest', 'Compile application code', 'Store session data permanently'], 0, 'Load balancers spread traffic across servers to improve throughput, availability and fault tolerance.'],
    ['Which statement correctly describes the CAP theorem?', ['During a network partition a system must choose between consistency and availability', 'A system can always guarantee consistency, availability and partition tolerance', 'Caches must always be consistent with the database', 'Availability requires strong consistency'], 0, 'Partitions are unavoidable in distributed systems, so you trade consistency against availability when one occurs.'],
    ['Which caching strategy writes to the cache and the database on every update?', ['Write-through', 'Write-around', 'Read-through only', 'Lazy eviction'], 0, 'Write-through writes synchronously to both layers, keeping them consistent at the cost of write latency.'],
  ],
  'JavaScript Promises': [
    ['What does Promise.all do if one of the promises rejects?', ['It rejects immediately with that reason', 'It waits for all and returns an array of results', 'It ignores the rejection', 'It resolves with undefined'], 0, 'Promise.all fails fast: it rejects as soon as any input promise rejects.'],
    ["What is the output order of: console.log('a'); setTimeout(()=>console.log('b'),0); Promise.resolve().then(()=>console.log('c')); console.log('d');", ['a, d, c, b', 'a, b, c, d', 'a, c, d, b', 'a, d, b, c'], 0, 'Synchronous code runs first (a, d), then microtasks such as promise callbacks (c), then macrotasks like setTimeout (b).'],
    ['What does an async function always return?', ['A Promise', 'The raw returned value', 'undefined', 'A generator'], 0, 'An async function wraps its return value in a Promise (or a rejected Promise if it throws).'],
  ],
  'Data Structures': [
    ['What is the average time complexity of lookup in a hash table with a good hash function?', ['O(log n)', 'O(n)', 'O(1)', 'O(n log n)'], 2, 'With a good hash function and few collisions, lookups take constant time on average.'],
    ['Which data structure is typically used to implement BFS?', ['Stack', 'Queue', 'Heap', 'Trie'], 1, 'BFS explores level by level, so it uses a FIFO queue.'],
    ['What is the worst-case search time in an unbalanced BST with n nodes?', ['O(1)', 'O(log n)', 'O(n log n)', 'O(n)'], 3, 'A degenerate (skewed) BST behaves like a linked list, so search is O(n).'],
  ],
  'Graph Algorithms': [
    ['Which algorithm finds single-source shortest paths in a graph with non-negative weights?', ['Kruskal', 'Dijkstra', 'Topological sort', 'Kosaraju'], 1, "Dijkstra's algorithm greedily settles the closest unvisited vertex and works when all weights are non-negative."],
    ['Which algorithm can detect negative-weight cycles?', ['Dijkstra', 'Prim', 'Bellman-Ford', 'BFS'], 2, 'Bellman-Ford relaxes all edges V-1 times; a further improvement on the V-th pass reveals a negative cycle.'],
    ['Topological sorting is possible only for...', ['Undirected graphs', 'Directed acyclic graphs', 'Any directed graph', 'Complete graphs'], 1, 'A cycle would create a circular ordering dependency, so only DAGs have a topological order.'],
  ],
  'SQL Queries': [
    ['Which clause filters groups after aggregation?', ['WHERE', 'GROUP BY', 'HAVING', 'ORDER BY'], 2, 'WHERE filters rows before grouping; HAVING filters groups after aggregate functions are computed.'],
    ['Which JOIN returns all rows from the left table even when there is no match on the right?', ['INNER JOIN', 'LEFT JOIN', 'CROSS JOIN', 'NATURAL JOIN'], 1, 'LEFT JOIN keeps every left-table row and fills right-side columns with NULL when unmatched.'],
    ['What does COUNT(column_name) ignore?', ['Duplicate values', 'Zero values', 'NULL values', 'Empty strings'], 2, 'COUNT(column) counts only non-NULL values, while COUNT(*) counts all rows.'],
  ],
};

function seedIfEmpty() {
  if (db.prepare('SELECT COUNT(*) c FROM questions').get().c === 0) {
    const ins = db.prepare(`INSERT INTO questions (title,diff,topic,tags,description,kind,fn_name,starter_js,tests,sql_setup)
      VALUES (@title,@diff,@topic,@tags,@desc,@kind,@fn,@starter,@tests,@sql_setup)`);
    db.transaction(() => {
      for (const q of Q) {
        ins.run({
          title: q.title, diff: q.diff, topic: q.topic, tags: q.tags, desc: q.desc,
          kind: q.kind || 'code', fn: q.fn || null, starter: starterFor(q),
          tests: JSON.stringify({ mode: q.mode || 'call', cases: q.tests }), sql_setup: q.sql_setup || null,
        });
      }
    })();
    console.log(`[seed] inserted ${Q.length} questions`);
  }
  if (db.prepare('SELECT COUNT(*) c FROM quiz_bank').get().c === 0) {
    const ins = db.prepare('INSERT INTO quiz_bank (topic,question,options,answer,explanation) VALUES (?,?,?,?,?)');
    let n = 0;
    db.transaction(() => {
      for (const [topic, list] of Object.entries(quiz)) for (const [q, o, a, e] of list) { ins.run(topic, q, JSON.stringify(o), a, e); n++; }
    })();
    console.log(`[seed] inserted ${n} quiz questions`);
  }
  const adminEmail = (process.env.ADMIN_EMAIL || 'admin@prepgrid.local').toLowerCase();
  if (!db.prepare('SELECT 1 FROM users WHERE email = ?').get(adminEmail)) {
    const pw = process.env.ADMIN_PASSWORD || 'Admin@12345';
    db.prepare("INSERT INTO users (first_name,last_name,email,password_hash,role,plan) VALUES ('Admin','',?,?, 'admin','Pro')")
      .run(adminEmail, bcrypt.hashSync(pw, 10));
    console.log(`[seed] admin created: ${adminEmail}${process.env.ADMIN_PASSWORD ? '' : ' / Admin@12345  (CHANGE THIS via ADMIN_PASSWORD in .env)'}`);
  }
}

module.exports = { seedIfEmpty, interviewBank };
