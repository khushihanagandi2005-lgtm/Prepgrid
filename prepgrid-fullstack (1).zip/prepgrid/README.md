# PrepGrid – full-stack placement-prep platform

Your `prepgrid_platform.html` mock, turned into a working app: **Express + SQLite backend (Node's built-in `node:sqlite`, nothing to compile), vanilla-JS frontend** (same design, same screens).

## Run it
Requires **Node 22.13 or newer** (Node 24 works). If you see an "ExperimentalWarning: SQLite" line on start, that's normal.

```bash
npm install
cp .env.example .env        # optional for local dev
npm start                   # http://localhost:3000
```
First start seeds 15 questions (with real test cases), a 26-question quiz bank and an admin account:
**admin@prepgrid.local / Admin@12345** (set `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env` *before* first start; change it otherwise).

Tests (server must be running with `RUN_RATE_LIMIT=1000` on a fresh DB): `PORT=3000 npm test` – 80 API checks + 26 UI checks.

## What is real now
| Area | Implementation |
|---|---|
| Auth | bcrypt passwords, JWT (1 day / 30 days with "remember me"), rate-limited. Forgot-password sends a 6-digit OTP (hashed, 10 min, 5 attempts). Without SMTP the OTP is printed in the server console and shown in the UI **in dev only**. |
| Practice | JavaScript solutions **actually execute** in an isolated child process (empty env, `vm` context, Node permission model, 2 s/test timeout, 96 MB cap). Visible tests on **Run**, hidden tests on **Submit**. SQL questions run on an in-memory SQLite DB. Solved/bookmarks/submissions are saved per user. |
| AI Interview | Server-side sessions, 8 adaptive questions, scoring + feedback, history & review (Pro). With `ANTHROPIC_API_KEY` Claude generates questions and scores answers; without it the built-in bank and an offline heuristic scorer are used (clearly labelled). Voice input uses the browser Web Speech API. |
| Quiz | Server grades answers (correct answers never sent early), shuffled options, server-enforced timer, AI coaching feedback, real leaderboard (Pro). With an AI key, missing questions are generated and cached. |
| Billing | Free limits enforced on the server (10 questions, 5 interviews/mo, 3 quizzes/mo, no history/leaderboard). Razorpay orders + HMAC signature verification + webhook. Without keys a **dev-only sandbox** checkout is used (disabled in production). |
| Dashboard / Admin | All numbers computed from the DB: streaks, topic mastery, weak areas, activity; admin question CRUD (with test cases), user search/ban, analytics. |

## Going to production
1. Set `NODE_ENV=production`, a strong `JWT_SECRET`, `ADMIN_PASSWORD`, `TRUST_PROXY=1` behind a proxy, and put the SQLite file (`DB_PATH`) on a persistent volume.
2. Add SMTP settings (OTP email) and Razorpay keys + `RAZORPAY_WEBHOOK_SECRET` (webhook URL: `/api/billing/webhook`, event `payment.captured`).
3. **Code execution**: the sandbox is hardened but Node `vm` is not a perfect security boundary. For public launch, run the server in a container with no secrets/network, or swap `server/exec.js` for a service like Judge0 (which also unlocks Python/Java/C++, currently reported as "not enabled").
4. Scale beyond one server by moving from SQLite to Postgres (queries are plain SQL).

## Layout
```
server/  index.js db.js sqlite.js seed.js lib.js ai.js exec.js sandbox/runner.js routes/{auth,questions,interview,quiz,billing,me,admin}.js
public/  index.html css/style.css js/app.js
tests/   e2e.js ui-smoke.js
```
